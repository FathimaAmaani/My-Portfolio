<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ config('app.name') }} - Admin Dashboard</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body class="font-sans text-gray-900 antialiased">
    <!-- Header Section -->
    <header class="bg-white shadow fixed w-full z-50">
        <nav class="container mx-auto px-6 py-3">
            <div class="flex justify-between items-center">
                <div class="flex items-center">
                    <a href="/" class="flex items-center">
                        <img src="{{ asset('images/merrymeals.png') }}" class="w-20 h-20" alt="Meals on Wheels Logo" />
                        <span class="ml-3 text-xl font-bold">Meals on Wheels</span>
                    </a>
                </div>

                <div class="hidden md:flex items-center space-x-8">
                    <a href="/about" class="text-gray-600 hover:text-gray-900">About Us</a>
                    <a href="/services" class="text-gray-600 hover:text-gray-900">Our Services</a>
                    <a href="/donate" class="text-gray-600 hover:text-gray-900">Donate</a>
                    @auth
                        <div class=" gap-3 flex items-center">
                            <div class=" border border-2 border-red-500 rounded-full w-[45px] h-[45px]"></div>
                            @if (Auth::user()->role == 'member')
                                <a href="{{ route('member.dashboard') }}"
                                    class="text-gray-600 hover:text-gray-900">{{ Auth::user()->name }}</a>
                            @elseif(Auth::user()->role == 'caregiver')
                                <a href="{{ route('caregiver.dashboard') }}"
                                    class="text-gray-600 hover:text-gray-900">{{ Auth::user()->name }}</a>
                            @elseif(Auth::user()->role == 'partner')
                                <a href="{{ route('partner.dashboard') }}"
                                    class="text-gray-600 hover:text-gray-900">{{ Auth::user()->name }}</a>
                            @elseif(Auth::user()->role == 'volunteer')
                                <a href="{{ route('volunteer.dashboard') }}"
                                    class="text-gray-600 hover:text-gray-900">{{ Auth::user()->name }}</a>
                            @elseif(Auth::user()->role == 'admin')
                                <a href="{{ route('admin.dashboard') }}"
                                    class="text-gray-600 hover:text-gray-900">{{ Auth::user()->name }}</a>
                            @endif

                            <form action="{{ route('logout') }}" method="POST" class="inline-block">
                                @csrf
                                <button type="submit"
                                    class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">Logout</button>
                            </form>
                        </div>
                    @else
                        <a href="{{ route('login') }}" class="text-gray-600 hover:text-gray-900">Login</a>
                        <a href="{{ route('register') }}"
                            class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">Join us</a>
                    @endauth
                </div>
            </div>
        </nav>
    </header>

    <div class="pt-24">
        <!-- Tabs Navigation -->
        <div class="bg-white shadow-sm">
            <div class="container mx-auto px-6">
                <div class="flex overflow-x-auto space-x-4 py-4">
                    <button
                        class=" text-red-600 border-red-600 tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">Overview</button>
                    <button
                        class=" tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">Members</button>
                    <button
                        class=" tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">Caregivers</button>
                    <button
                        class=" tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">Partners</button>
                    <button
                        class=" tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">Volunteers</button>
                    <button
                        class=" tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">Meals
                        Management</button>
                    <button
                        class=" tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">Delivery
                        Management</button>
                </div>
            </div>
        </div>

        <div class="container mx-auto px-6">
            <!-- Tab Contents -->
            {{-- tab overview  --}}
            {{-- <div id="overview-tab" class="tab-content">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <!-- Statistics Cards -->
                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <h3 class="text-xl font-bold mb-4">Total Members</h3>
                            <p class="text-3xl text-red-600">{{count($usersByRole['member'] ?? [])}}</p>
                        </div>
                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <h3 class="text-xl font-bold mb-4">Total Caregivers</h3>
                            <p class="text-3xl text-red-600">{{count($usersByRole['caregiver'] ?? [])}}</p>
                        </div>
                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <h3 class="text-xl font-bold mb-4">Total Volunteers</h3>
                            <p class="text-3xl text-red-600">{{count($usersByRole['volunteer'] ?? [])}}</p>
                        </div>
                    </div>
                </div> --}}
            <div id="overview-tab" class="tab-content mt-5">
                <!-- Header Section -->
                <div class="flex items-center justify-between mb-8">
                    <h2 class="text-3xl font-bold tracking-tight">Analytics Dashboard</h2>
                    <div class="bg-white p-2 rounded-lg shadow flex items-center">
                        <span class="text-sm text-gray-600">Last updated: 5 minutes ago</span>
                    </div>
                </div>

                <!-- Top Stats Cards -->
                <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
                    <div class="bg-white p-6 rounded-lg shadow-lg">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-sm font-medium">Total Members</h3>
                            <svg class="h-4 w-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-width="2"
                                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                            </svg>
                        </div>
                        <div class="text-2xl font-bold">{{ count($usersByRole['member'] ?? []) }}</div>
                        <p class="text-xs text-gray-500">+20% from last month</p>
                        <span
                            class="inline-block px-2 py-1 mt-2 text-xs font-semibold text-white bg-green-500 rounded-full">Active</span>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-lg">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-sm font-medium">Total Caregivers</h3>
                            <svg class="h-4 w-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-width="2"
                                    d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                            </svg>
                        </div>
                        <div class="text-2xl font-bold">{{ count($usersByRole['caregiver'] ?? []) }}</div>
                        <p class="text-xs text-gray-500">+15% from last month</p>
                        <span
                            class="inline-block px-2 py-1 mt-2 text-xs font-semibold text-white bg-green-500 rounded-full">Active</span>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-lg">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-sm font-medium">Total Volunteers</h3>
                            <svg class="h-4 w-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-width="2"
                                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                            </svg>
                        </div>
                        <div class="text-2xl font-bold">{{ count($usersByRole['volunteer'] ?? []) }}</div>
                        <p class="text-xs text-gray-500">+10% from last month</p>
                        <span
                            class="inline-block px-2 py-1 mt-2 text-xs font-semibold text-white bg-green-500 rounded-full">Active</span>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-lg">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-sm font-medium">Total Partners</h3>
                            <svg class="h-4 w-4 text-gray-500" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-width="2"
                                    d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                            </svg>
                        </div>
                        <div class="text-2xl font-bold">{{ count($usersByRole['partner'] ?? []) }}</div>
                        <p class="text-xs text-gray-500">+5% from last month</p>
                        <span
                            class="inline-block px-2 py-1 mt-2 text-xs font-semibold text-white bg-green-500 rounded-full">Active</span>
                    </div>
                </div>

                <!-- Charts Section -->
                <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    <!-- Add your charts here using a JavaScript charting library like Chart.js -->
                    <div class="bg-white p-6 rounded-lg shadow-lg">
                        <h3 class="text-lg font-semibold mb-4">Member Growth</h3>
                        <canvas id="memberGrowthChart" width="400" height="300"></canvas>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-lg">
                        <h3 class="text-lg font-semibold mb-4">Volunteer Distribution</h3>
                        <canvas id="volunteerDistChart" width="400" height="300"></canvas>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-lg">
                        <h3 class="text-lg font-semibold mb-4">Monthly Meals Served</h3>
                        <canvas id="mealsServedChart" width="400" height="300"></canvas>
                    </div>
                </div>
                <!-- Add these cards after your existing charts section -->
                <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-3 mt-8">
                    <!-- Donation Campaign Progress -->
                    <div class="bg-white p-6 rounded-lg shadow-lg">
                        <h3 class="text-lg font-semibold mb-4">Donation Campaign Progress</h3>
                        <div class="space-y-4">
                            <div>
                                <div class="flex justify-between mb-1">
                                    <span class="text-sm font-medium">Summer Campaign</span>
                                    <span class="text-sm font-medium">85%</span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2">
                                    <div class="bg-green-500 h-2 rounded-full" style="width: 85%"></div>
                                </div>
                            </div>
                            <div>
                                <div class="flex justify-between mb-1">
                                    <span class="text-sm font-medium">Winter Drive</span>
                                    <span class="text-sm font-medium">65%</span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2">
                                    <div class="bg-blue-500 h-2 rounded-full" style="width: 65%"></div>
                                </div>
                            </div>
                        </div>
                    </div>



                    <!-- Volunteer Hours -->
                    <div class="bg-white p-6 rounded-lg shadow-lg">
                        <h3 class="text-lg font-semibold mb-4">Volunteer Hours</h3>
                        <canvas id="volunteerHoursChart" width="400" height="300"></canvas>
                    </div>

                    <!-- Service Coverage Area -->
                    <div class="bg-white p-6 rounded-lg shadow-lg">
                        <h3 class="text-lg font-semibold mb-4">Service Coverage Area</h3>
                        <canvas id="coverageChart" width="400" height="300"></canvas>
                    </div>
                </div>
            </div>


            <!-- Members Tab Content -->
            <div id="members-tab" class="tab-content hidden">
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h2 class="text-2xl font-bold mb-4">Members Management</h2>
                    <table class="w-full table-auto">
                        <thead class="bg-gray-50">
                            <tr>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    #</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Name</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Email</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Phone</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Address</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Age</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Medical Condition</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Allergies</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Dietary Restrictions</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Meal Status</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Assigned_caregiver</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            @foreach ($usersByRole['member'] ?? [] as $user)
                                <tr>
                                    <td class="px-6 py-4">{{ $user->id }}</td>
                                    <td class="px-6 py-4">{{ $user->name }}</td>
                                    <td class="px-6 py-4">{{ $user->email }}</td>
                                    <td class="px-6 py-4">{{ $user->phone_number }}</td>
                                    <td class="px-6 py-4">
                                        <div class="line-clamp-2 max-w-[200px]">{{ $user->address }}</div>
                                    </td>
                                    <td class="px-6 py-4">{{ $user->age }}</td>
                                    <td class="px-6 py-4">{{ $user->member->medical_condition ?? 'N\A' }}</td>
                                    <td class="px-6 py-4">{{ $user->member->allergies ?? 'N\A' }}</td>
                                    <td class="px-6 py-4">{{ $user->member->dietary_restrictions ?? 'N\A' }}</td>
                                    <td class="px-6 py-4">{{ $user->member->meal_status ?? 'N\A' }}</td>
                                    <td class="px-6 py-4">{{ $user->member->caregiver->user->name ?? 'N\A' }}</td>

                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>


            <!-- Caregivers Tab Content -->
            <div id="caregivers-tab" class="tab-content hidden">
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h2 class="text-2xl font-bold mb-4">Caregivers Management</h2>

                    <!-- Unassigned Members Section -->
                    <div class="mb-8">
                        <h3 class="text-xl font-semibold mb-4">Members Without Caregivers</h3>
                        <div class="overflow-x-auto">
                            <table class="w-full table-auto">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th
                                            class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Member Name</th>
                                        <th
                                            class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Medical Condition</th>
                                        <th
                                            class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Assign Caregiver</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    @foreach ($unassignedMembers as $member)
                                        <tr>
                                            <td class="px-6 py-4">{{ $member->user->name }}</td>
                                            <td class="px-6 py-4">{{ $member->medical_condition }}</td>
                                            <td class="px-6 py-4">
                                                <form action="{{ route('admin.assignCaregiver') }}" method="POST"
                                                    class="flex gap-2">
                                                    @csrf
                                                    <input type="hidden" name="member_id"
                                                        value="{{ $member->id }}">
                                                    <select name="caregiver_id"
                                                        class="rounded-md border-gray-300 focus:border-red-500 focus:ring-red-500">
                                                        <option value="">Select Caregiver</option>
                                                        @foreach ($usersByRole['caregiver'] as $user)
                                                            @if (!$user->caregiver->assignedMember)
                                                                <option value="{{ $user->caregiver->id }}">
                                                                    {{ $user->name }}</option>
                                                            @endif
                                                        @endforeach
                                                    </select>
                                                    <button type="submit"
                                                        class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">
                                                        Assign
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Existing Caregivers Table -->
                    <div class="mt-8">
                        <h3 class="text-xl font-semibold mb-4">All Caregivers</h3>
                        <!-- Your existing caregivers table here -->
                        <table class="w-full table-auto">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        #</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Name</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Email</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Phone</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Address</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Age</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Specialization</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Experience</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Availability</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Assigned Member</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach ($usersByRole['caregiver'] ?? [] as $user)
                                    <tr>
                                        <td class="px-6 py-4">{{ $user->id }}</td>
                                        <td class="px-6 py-4">{{ $user->name }}</td>
                                        <td class="px-6 py-4">{{ $user->email }}</td>
                                        <td class="px-6 py-4">{{ $user->phone_number }}</td>
                                        <td class="px-6 py-4">{{ $user->address }}</td>
                                        <td class="px-6 py-4">{{ $user->age }}</td>
                                        <td class="px-6 py-4">{{ $user->caregiver->specialization ?? 'N\A' }}</td>
                                        <td class="px-6 py-4">{{ $user->caregiver->experience ?? 'N\A' }}</td>
                                        <td class="px-6 py-4">{{ $user->caregiver->availability ?? 'N\A' }}</td>
                                        <td class="px-6 py-4">
                                            {{ $user->caregiver->assignedMember->user->name ?? 'N\A' }}
                                        </td>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {{-- partners tab content --}}
            <div id="partners-tab" class="tab-content hidden">
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h2 class="text-2xl font-bold mb-4">Partners Management</h2>
                    <table class="w-full table-auto">
                        <thead class="bg-gray-50">
                            <tr>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    #</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Name</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Email</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Phone</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Address</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Organization Name</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Organization Wesbstie</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Partnership Term</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            @foreach ($usersByRole['partner'] ?? [] as $user)
                                <tr>
                                    <td class="px-6 py-4">{{ $user->id }}</td>
                                    <td class="px-6 py-4">{{ $user->name }}</td>
                                    <td class="px-6 py-4">{{ $user->email }}</td>
                                    <td class="px-6 py-4">{{ $user->phone_number }}</td>
                                    <td class="px-6 py-4">{{ $user->address }}</td>
                                    <td class="px-6 py-4">{{ $user->partner->org_name ?? 'N\A' }}</td>
                                    <td class="px-6 py-4">{{ $user->partner->org_url ?? 'N\A' }}</td>
                                    <td class="px-6 py-4">{{ $user->partner->partnership_term ?? 'N\A' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

            {{-- volunteers tab content --}}
            <div id="volunteers-tab" class="tab-content hidden">
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h2 class="text-2xl font-bold mb-4">Volunteers Management</h2>
                    <table class="w-full table-auto">
                        <thead class="bg-gray-50">
                            <tr>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    #</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Name</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Email</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Phone</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Address</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Age</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Experience</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Availability</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Status</th>
                                <th
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Rider License</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            @foreach ($usersByRole['volunteer'] ?? [] as $user)
                                <tr>
                                    <td class="px-6 py-4">{{ $user->id }}</td>
                                    <td class="px-6 py-4">{{ $user->name }}</td>
                                    <td class="px-6 py-4">{{ $user->email }}</td>
                                    <td class="px-6 py-4">{{ $user->phone_number }}</td>
                                    <td class="px-6 py-4">{{ $user->address }}</td>
                                    <td class="px-6 py-4">{{ $user->age }}</td>
                                    <td class="px-6 py-4">{{ $user->volunteer->vol_experience ?? 'N\A' }}</td>
                                    <td class="px-6 py-4">{{ $user->volunteer->vol_availability ?? 'N\A' }}</td>
                                    <td class="px-6 py-4">{{ $user->volunteer->status ?? 'N\A' }}</td>
                                    <td class="px-6 py-4">{{ $user->volunteer->rider_license ?? 'N\A' }}
                                    </td>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Meals Management Tab Content -->
            <div id="meals-tab" class="tab-content hidden">
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-2xl font-bold">Meals Management</h2>
                        <button onclick="openMealModal()"
                            class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">
                            Add New Meal
                        </button>
                    </div>

                    <!-- Meals Grid -->
                    {{-- <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        @foreach ($meals as $meal)
                            <div class="bg-white rounded-lg shadow p-6 border border-gray-200">
                                <h3 class="text-xl font-semibold mb-2">{{ $meal->name }}</h3>
                                <p class="text-gray-600 mb-4">{{ $meal->description }}</p>
                                <div class="flex flex-wrap gap-2 mb-4">
                                    @foreach ($meal->dietary_restrictions as $restriction)
                                        <span
                                            class="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
                                            {{ $restriction }}
                                        </span>
                                    @endforeach
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-500">Quantity: {{ $meal->quantity }}</span>
                                    <div class="flex gap-2">
                                        <button class="text-blue-600 hover:text-blue-800">Edit</button>
                                        <button class="text-red-600 hover:text-red-800">Delete</button>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div> --}}
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        @foreach ($meals as $meal)
                            <div class="bg-white rounded-lg shadow p-6 border border-gray-200">
                                <div class="flex justify-between items-start mb-2">
                                    <h3 class="text-xl font-semibold">{{ $meal->name }}</h3>
                                    <span
                                        class="px-2 py-1 rounded-full text-xs font-semibold {{ $meal->status === 'hot' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800' }}">
                                        {{ ucfirst($meal->status) }}
                                    </span>
                                </div>
                                <p class="text-gray-600 mb-4">{{ $meal->description }}</p>
                                <div class="flex flex-wrap gap-2 mb-4">
                                    @foreach ($meal->dietary_restrictions as $restriction)
                                        <span
                                            class="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
                                            {{ $restriction }}
                                        </span>
                                    @endforeach
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-500">Quantity: {{ $meal->quantity }}</span>
                                    <div class="flex gap-2">
                                        <button onclick="editMeal({{ $meal->id }})"
                                            class="text-blue-600 hover:text-blue-800 font-medium">Edit</button>
                                        <form action="{{ route('admin.meals.destroy', $meal->id) }}" method="POST"
                                            class="inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="text-red-600 hover:text-red-800 font-medium"
                                                onclick="return confirm('Are you sure you want to delete this meal?')">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>

                </div>

                <!-- Add Meal Modal -->
                <div id="mealModal"
                    class="mt-[30px] hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
                    <div class="relative top-20 mx-auto px-5 pb-5 border w-96 shadow-lg rounded-md bg-white">
                        <div class="mt-3">
                            <h3 class="text-lg font-medium leading-6 text-gray-900 mb-4">Add New Meal</h3>
                            <form id="addMealForm" method="POST" action="{{ route('admin.meals.store') }}">
                                @csrf
                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Meal Name</label>
                                    <input type="text" name="name" required
                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                                </div>

                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Meal Status</label>
                                    <select name="status" required
                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                                        <option value="hot">Hot Meal</option>
                                        <option value="frozen">Frozen Meal</option>
                                    </select>
                                </div>

                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Description</label>
                                    <textarea name="description" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"></textarea>
                                </div>

                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Dietary Restrictions</label>
                                    <div class="mt-2 space-y-2">
                                        <label class="inline-flex items-center">
                                            <input type="checkbox" name="dietary_restrictions[]" value="gluten-free"
                                                class="rounded">
                                            <span class="ml-2">Gluten-free</span>
                                        </label>
                                        <label class="inline-flex items-center">
                                            <input type="checkbox" name="dietary_restrictions[]" value="vegan"
                                                class="rounded">
                                            <span class="ml-2">Vegan</span>
                                        </label>
                                        <label class="inline-flex items-center">
                                            <input type="checkbox" name="dietary_restrictions[]" value="hala"
                                                class="rounded">
                                            <span class="ml-2">Halal</span>
                                        </label>
                                        <label class="inline-flex items-center">
                                            <input type="checkbox" name="dietary_restrictions[]" value="low-sodium"
                                                class="rounded">
                                            <span class="ml-2">Low-Sodium</span>
                                        </label>
                                    </div>
                                </div>

                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Quantity</label>
                                    <input type="number" name="quantity" required
                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                                </div>

                                <div class="flex justify-end gap-3">
                                    <button type="button" onclick="closeMealModal()"
                                        class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">
                                        Cancel
                                    </button>
                                    <button type="submit"
                                        class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">
                                        Add Meal
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- Add Edit Meal Modal -->
                <div id="editMealModal"
                    class="mt-[30px] hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
                    <div class="relative top-20 mx-auto px-5 pb-5 border w-96 shadow-lg rounded-md bg-white">
                        <div class="mt-3">
                            <h3 class="text-lg font-medium leading-6 text-gray-900 mb-4">Edit Meal</h3>
                            <form id="editMealForm" method="POST">
                                @csrf
                                @method('PUT')
                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Meal Name</label>
                                    <input type="text" name="name" id="edit_name" required
                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                                </div>

                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Description</label>
                                    <textarea name="description" id="edit_description" required
                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"></textarea>
                                </div>

                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Dietary Restrictions</label>
                                    <div class="mt-2 space-y-2">
                                        <label class="inline-flex items-center">
                                            <input type="checkbox" name="dietary_restrictions[]" value="gluten-free"
                                                class="rounded">
                                            <span class="ml-2">Gluten-free</span>
                                        </label>
                                        <label class="inline-flex items-center">
                                            <input type="checkbox" name="dietary_restrictions[]" value="vegan"
                                                class="rounded">
                                            <span class="ml-2">Vegan</span>
                                        </label>
                                        <label class="inline-flex items-center">
                                            <input type="checkbox" name="dietary_restrictions[]" value="halal"
                                                class="rounded">
                                            <span class="ml-2">Halal</span>
                                        </label>
                                        <label class="inline-flex items-center">
                                            <input type="checkbox" name="dietary_restrictions[]" value="low-sodium"
                                                class="rounded">
                                            <span class="ml-2">Low-Sodium</span>
                                        </label>
                                    </div>
                                </div>

                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Status</label>
                                    <select name="status" id="edit_status" required
                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                                        <option value="hot">Hot Meal</option>
                                        <option value="frozen">Frozen Meal</option>
                                    </select>
                                </div>

                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Quantity</label>
                                    <input type="number" name="quantity" id="edit_quantity" required
                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                                </div>

                                <div class="flex justify-end gap-3">
                                    <button type="button" onclick="closeEditModal()"
                                        class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">Cancel</button>
                                    <button type="submit"
                                        class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">Update
                                        Meal</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Delivery Management Tab Content -->
            <div id="delivery-tab" class="tab-content hidden">
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-2xl font-bold">Delivery Management</h2>
                        <button onclick="openDeliveryModal()"
                            class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">
                            Assign New Delivery
                        </button>
                    </div>

                    <!-- Deliveries Table -->
                    <div class="overflow-x-auto">
                        <table class="w-full table-auto">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        ID</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Volunteer</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Member</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Meal</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Status</th>

                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach ($deliveries as $delivery)
                                    <tr>
                                        <td class="px-6 py-4">{{ $delivery->id }}</td>
                                        <td class="px-6 py-4">{{ $delivery->volunteer->user->name }}</td>
                                        <td class="px-6 py-4">{{ $delivery->member->user->name }}</td>
                                        <td class="px-6 py-4">{{ $delivery->meal->name }}</td>
                                        <td class="px-6 py-4">
                                            <span
                                                class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                {{ $delivery->status === 'Completed'
                                    ? 'bg-green-100 text-green-800'
                                    : ($delivery->status === 'In Progress'
                                        ? 'bg-blue-100 text-blue-800'
                                        : 'bg-yellow-100 text-yellow-800') }}">
                                                {{ $delivery->status }}
                                            </span>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Add Delivery Modal -->
                <div id="deliveryModal"
                    class="mt-[80px] hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
                    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                        <div class="mt-3">
                            <h3 class="text-lg font-medium leading-6 text-gray-900 mb-4">Assign New Delivery</h3>
                            <form method="POST" action="{{ route('admin.deliveries.store') }}">
                                @csrf
                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Volunteer</label>
                                    <select name="volunteer_id" required
                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                                        @foreach ($volunteers as $volunteer)
                                            <option value="{{ $volunteer->id }}">{{ $volunteer->user->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Member</label>
                                    <select name="member_id" required
                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                                        @foreach ($members as $member)
                                            <option value="{{ $member->id }}">{{ $member->user->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700">Meal</label>
                                    <select name="meal_id" required
                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                                        @foreach ($meals as $meal)
                                            <option value="{{ $meal->id }}">{{ $meal->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="flex justify-end gap-3">
                                    <button type="button" onclick="closeDeliveryModal()"
                                        class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">
                                        Cancel
                                    </button>
                                    <button type="submit"
                                        class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">
                                        Assign Delivery
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>


    <footer class="bg-gray-800 text-white py-12 mt-[200px]">
        <div class="container mx-auto px-6">
            <div class="grid md:grid-cols-4 gap-8">
                <div>
                    <h3 class="text-xl font-semibold mb-4">About Us</h3>
                    <p class="text-gray-300">Meals on Wheels delivers nutritious meals to those in need,
                        bringing communities together through compassionate service.</p>
                </div>
                <div>
                    <h3 class="text-xl font-semibold mb-4">Quick Links</h3>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-300 hover:text-white transition">Volunteer</a>
                        </li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition">Donate</a>
                        </li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition">Partner With
                                Us</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition">Contact</a>
                        </li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-xl font-semibold mb-4">Contact Info</h3>
                    <ul class="space-y-2 text-gray-300">
                        <li>Phone: (555) 123-4567</li>
                        <li>Email: info@mealsonwheels.org</li>
                        <li>Address: 123 Care Street</li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-xl font-semibold mb-4">Follow Us</h3>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-300 hover:text-white transition">
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                                <path
                                    d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                            </svg>
                        </a>
                        <a href="#" class="text-gray-300 hover:text-white transition">
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                                <path
                                    d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
                            </svg>
                        </a>
                        <a href="#" class="text-gray-300 hover:text-white transition">
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                                <path
                                    d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.897 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.897-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
                <p>&copy; {{ date('Y') }} Meals on Wheels. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Tab switching functionality
        const tabButtons = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');

        tabButtons.forEach((button, index) => {
            button.addEventListener('click', () => {
                // Remove active states
                tabButtons.forEach(btn => btn.classList.remove('text-red-600', 'border-red-600'));
                tabContents.forEach(content => content.classList.add('hidden'));

                // Add active states
                button.classList.add('text-red-600', 'border-red-600');
                tabContents[index].classList.remove('hidden');
            });
        });

        const ctx = document.getElementById('memberGrowthChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Member Growth',
                    data: [12, 19, 3, 5, 2, 3],
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1
                }]
            }
        });
        // Volunteer Distribution Chart
        const volunteerCtx = document.getElementById('volunteerDistChart').getContext('2d');
        new Chart(volunteerCtx, {
            type: 'pie',
            data: {
                labels: ['Delivery', 'Kitchen', 'Administrative', 'Events'],
                datasets: [{
                    data: [30, 25, 15, 30],
                    backgroundColor: [
                        '#FF6B6B',
                        '#4ECDC4',
                        '#45B7D1',
                        '#96CEB4'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        // Monthly Meals Served Chart
        const mealsCtx = document.getElementById('mealsServedChart').getContext('2d');
        new Chart(mealsCtx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Meals Served',
                    data: [1200, 1900, 1700, 1600, 2100, 1800],
                    backgroundColor: '#FF6B6B',
                    borderColor: '#FF6B6B',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Number of Meals'
                        }
                    }
                }
            }
        });

        // Volunteer Hours Chart
        const volunteerHoursCtx = document.getElementById('volunteerHoursChart').getContext('2d');
        new Chart(volunteerHoursCtx, {
            type: 'bar',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Hours Contributed',
                    data: [28, 35, 40, 32, 45, 50, 25],
                    backgroundColor: '#45B7D1'
                }]
            },
            options: {
                responsive: true
            }
        });

        // Service Coverage Area Chart
        const coverageCtx = document.getElementById('coverageChart').getContext('2d');
        new Chart(coverageCtx, {
            type: 'radar',
            data: {
                labels: ['North', 'East', 'South', 'West', 'Central'],
                datasets: [{
                    label: 'Coverage %',
                    data: [85, 75, 90, 80, 95],
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: '#4ECDC4'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });

        function openMealModal() {
            document.getElementById('mealModal').classList.remove('hidden');
        }

        function closeMealModal() {
            document.getElementById('mealModal').classList.add('hidden');
        }

        function openDeliveryModal() {
            document.getElementById('deliveryModal').classList.remove('hidden');
        }

        function closeDeliveryModal() {
            document.getElementById('deliveryModal').classList.add('hidden');
        }

        function editMeal(mealId) {
            fetch(`/admin/meals/${mealId}/edit`)
                .then(response => response.json())
                .then(meal => {
                    const form = document.getElementById('editMealForm');
                    form.action = `/admin/meals/${mealId}`;

                    document.getElementById('edit_name').value = meal.name;
                    document.getElementById('edit_description').value = meal.description;
                    document.getElementById('edit_status').value = meal.status;
                    document.getElementById('edit_quantity').value = meal.quantity;

                    // Handle dietary restrictions checkboxes
                    const checkboxes = form.querySelectorAll('input[name="dietary_restrictions[]"]');
                    checkboxes.forEach(checkbox => {
                        checkbox.checked = meal.dietary_restrictions.includes(checkbox.value);
                    });

                    document.getElementById('editMealModal').classList.remove('hidden');
                });
        }

        function closeEditModal() {
            document.getElementById('editMealModal').classList.add('hidden');
        }
        const members = @json($members);
        const meals = @json($meals);
        document.querySelector('select[name="member_id"]').addEventListener('change', function() {
            const memberId = this.value;
            const mealSelect = document.querySelector('select[name="meal_id"]');

            // Clear existing options
            mealSelect.innerHTML = '';

            // Filter meals based on member's meal status
            const member = members.find(m => m.id == memberId);
            const memberMealStatus = member.meal_status;

            meals.forEach(meal => {
                if (meal.status === memberMealStatus) {
                    const option = new Option(meal.name, meal.id);
                    mealSelect.add(option);
                }
            });
        });

    </script>

</body>

</html>
