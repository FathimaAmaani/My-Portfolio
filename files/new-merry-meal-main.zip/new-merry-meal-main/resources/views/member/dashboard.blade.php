

    <!DOCTYPE html>
    <html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{{ config('app.name') }} - MemberDashboard</title>
        @vite(['resources/css/app.css', 'resources/js/app.js'])
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    </head>

    <body class="font-sans text-gray-900 antialiased">
        <!-- Header Section -->
        <header class="bg-white shadow fixed w-full z-50">
            <nav class="container mx-auto px-6 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center">
                        <a href="/" class="flex items-center">
                            <img src="{{ asset('images/merrymeals.png') }}" class="w-20 h-20" alt="Meals on Wheels Logo" />
                            <span class="ml-3 text-xl font-bold">Meals on Wheels</span>
                        </a>
                    </div>

                    <div class="hidden md:flex items-center space-x-8">
                        <a href="/about" class="text-gray-600 hover:text-gray-900">About Us</a>
                        <a href="/services" class="text-gray-600 hover:text-gray-900">Our Services</a>
                        <a href="/donate" class="text-gray-600 hover:text-gray-900">Donate</a>
                        @auth
                        <div class=" gap-3 flex items-center">
                            <div class=" border border-2 border-red-500 rounded-full w-[45px] h-[45px]"></div>
                            @if(Auth::user()->role == 'member')
                                <a href="{{ route('member.dashboard') }}" class="text-gray-600 hover:text-gray-900">{{Auth::user()->name}}</a>

                            @elseif(Auth::user()->role == 'caregiver')
                                <a href="{{ route('caregiver.dashboard') }}" class="text-gray-600 hover:text-gray-900">{{Auth::user()->name}}</a>

                            @elseif(Auth::user()->role == 'partner')
                                <a href="{{ route('partner.dashboard') }}" class="text-gray-600 hover:text-gray-900">{{Auth::user()->name}}</a>

                            @elseif(Auth::user()->role == 'volunteer')
                                <a href="{{ route('volunteer.dashboard') }}" class="text-gray-600 hover:text-gray-900">{{Auth::user()->name}}</a>

                                @elseif(Auth::user()->role == 'admin')
                                <a href="{{ route('admin.dashboard') }}" class="text-gray-600 hover:text-gray-900">{{Auth::user()->name}}</a>
                                @endif

                            <form action="{{ route('logout') }}" method="POST" class="inline-block">
                                @csrf
                                <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">Logout</button>
                            </form>
                        </div>
                        @else
                            <a href="{{ route('login') }}" class="text-gray-600 hover:text-gray-900">Login</a>
                            <a href="{{ route('register') }}"
                                class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">Join us</a>
                        @endauth
                    </div>
                </div>
            </nav>
        </header>
        <!-- Session Status -->

        {{-- <div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100">
            <h1 class=" mt-[150px]">Welcome, {{ $member->user->name }}</h1>
            <table class="w-[500px] mt-4">
                <tr class="border-b border-black text-left">
                    <th class=" py-3">Name</th>
                    <td class=" py-3">{{ $member->user->name }}</td>
                </tr>
                <tr class="border-b border-black text-left">
                    <th class=" py-3">Email</th>
                    <td class=" py-3">{{ $member->user->email }}</td>
                </tr>
                <tr class="border-b border-black text-left">
                    <th class=" py-3">Phone Number</th>
                    <td class=" py-3">{{ $member->user->phone_number }}</td>
                </tr>
                <tr class="border-b border-black text-left">
                    <th class=" py-3">Address</th>
                    <td class=" py-3">{{ $member->user->address }}</td>
                </tr>
                <tr class="border-b border-black text-left">
                    <th class=" py-3">Medical Condition</th>
                    <td class=" py-3">{{ $member->medical_condition }}</td>
                </tr>
                <tr class="border-b border-black text-left">
                    <th class=" py-3">Allergies</th>
                    <td class=" py-3">{{ $member->allergies }}</td>
                </tr>
                <tr class="border-b border-black text-left">
                    <th class=" py-3">Dietary Restrictions</th>
                    <td class=" py-3">{{ $member->dietary_restrictions }}</td>
                </tr>

                <tr class="border-b border-black text-left">
                    <th class=" py-3">Caregiver</th>
                    <td class=" py-3">
                        @if($member->caregiver)
                            {{ $member->caregiver->user->name }}
                        @else
                            None
                    @endif</td>
                </tr>
            </table>
        </div> --}}

        <div class="pt-24">
            <!-- Tabs Navigation -->
            <div class="bg-white shadow-sm">
                <div class="container mx-auto px-6">
                    <div class="flex overflow-x-auto space-x-4 py-4">
                        <button class="text-red-600 border-red-600 tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">Profile</button>
                        <button class="tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">Available Meals</button>
                        <button class="tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">My Deliveries</button>
                    </div>
                </div>
            </div>

            <div class="container mx-auto px-6 py-8">
                <!-- Profile Tab -->
                <div id="profile-tab" class="tab-content">
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <h2 class="text-2xl font-bold mb-6">My Profile</h2>
                        <div class="grid md:grid-cols-2 gap-6">
                            <!-- Personal Information -->
                            <div>
                                <h3 class="text-lg font-semibold mb-4">Personal Details</h3>
                                <div class="space-y-3">
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Name:</span>
                                        <span class="font-medium">{{ $member->user->name }}</span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Email:</span>
                                        <span class="font-medium">{{ $member->user->email }}</span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Phone:</span>
                                        <span class="font-medium">{{ $member->user->phone_number }}</span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Address:</span>
                                        <span class="font-medium">{{ $member->user->address }}</span>
                                    </p>
                                </div>
                            </div>

                            <!-- Medical Information -->
                            <div>
                                <h3 class="text-lg font-semibold mb-4">Medical Information</h3>
                                <div class="space-y-3">
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Medical Condition:</span>
                                        <span class="font-medium">{{ $member->medical_condition }}</span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Allergies:</span>
                                        <span class="font-medium">{{ $member->allergies }}</span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Dietary Restrictions:</span>
                                        <span class="font-medium">{{ $member->dietary_restrictions }}</span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Assigned Caregiver:</span>
                                        <span class="font-medium">{{ $member->caregiver->user->name ?? 'None' }}</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Meals Tab -->
                <div id="meals-tab" class="tab-content hidden">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        @foreach($meals as $meal)
                        <div class="bg-white rounded-lg shadow-lg p-6">
                            <h3 class="text-xl font-semibold mb-2">{{ $meal->name }}</h3>
                            <p class="text-gray-600 mb-4">{{ $meal->description }}</p>
                            <div class="flex flex-wrap gap-2 mb-4">
                                @foreach($meal->dietary_restrictions as $restriction)
                                <span class="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
                                    {{ $restriction }}
                                </span>
                                @endforeach
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-500">Quantity Available: {{ $meal->quantity }}</span>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>

                <!-- Deliveries Tab -->
                <div id="deliveries-tab" class="tab-content hidden">
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <h2 class="text-2xl font-bold mb-6">My Deliveries</h2>
                        <div class="space-y-6">
                            @forelse($deliveries as $delivery)
                            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                                <div class="flex justify-between items-start mb-4">
                                    <div>
                                        <h3 class="text-lg font-semibold">Delivery #{{ $delivery->id }}</h3>
                                        <p class="text-sm text-gray-500">Ordered on {{ $delivery->created_at->format('M d, Y') }}</p>
                                    </div>
                                    <span class="px-3 py-1 rounded-full text-sm font-semibold
                                        {{ $delivery->status === 'Completed' ? 'bg-green-100 text-green-800' :
                                           ($delivery->status === 'In Progress' ? 'bg-blue-100 text-blue-800' :
                                           'bg-yellow-100 text-yellow-800') }}">
                                        {{ $delivery->status }}
                                    </span>
                                </div>
                                <div class="space-y-3">
                                    <div>
                                        <h4 class="text-sm font-medium text-gray-500">Meal</h4>
                                        <p class="font-medium">{{ $delivery->meal->name }}</p>
                                    </div>
                                    <div>
                                        <h4 class="text-sm font-medium text-gray-500">Volunteer Assigned</h4>
                                        <p class="font-medium">{{ $delivery->volunteer->user->name }}</p>
                                    </div>
                                </div>
                            </div>
                            @empty
                            <div class="text-center py-8 text-gray-500">
                                No deliveries found.
                            </div>
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>
        </div>





        <footer class="bg-gray-800 text-white py-12">
            <div class="container mx-auto px-6">
                <div class="grid md:grid-cols-4 gap-8">
                    <div>
                        <h3 class="text-xl font-semibold mb-4">About Us</h3>
                        <p class="text-gray-300">Meals on Wheels delivers nutritious meals to those in need,
                            bringing communities together through compassionate service.</p>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold mb-4">Quick Links</h3>
                        <ul class="space-y-2">
                            <li><a href="#" class="text-gray-300 hover:text-white transition">Volunteer</a>
                            </li>
                            <li><a href="#" class="text-gray-300 hover:text-white transition">Donate</a>
                            </li>
                            <li><a href="#" class="text-gray-300 hover:text-white transition">Partner With
                                    Us</a></li>
                            <li><a href="#" class="text-gray-300 hover:text-white transition">Contact</a>
                            </li>
                        </ul>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold mb-4">Contact Info</h3>
                        <ul class="space-y-2 text-gray-300">
                            <li>Phone: (555) 123-4567</li>
                            <li>Email: info@mealsonwheels.org</li>
                            <li>Address: 123 Care Street</li>
                        </ul>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold mb-4">Follow Us</h3>
                        <div class="flex space-x-4">
                            <a href="#" class="text-gray-300 hover:text-white transition">
                                <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                                </svg>
                            </a>
                            <a href="#" class="text-gray-300 hover:text-white transition">
                                <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
                                </svg>
                            </a>
                            <a href="#" class="text-gray-300 hover:text-white transition">
                                <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.897 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.897-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
                    <p>&copy; {{ date('Y') }} Meals on Wheels. All rights reserved.</p>
                </div>
            </div>
        </footer>

        <script>
            const tabButtons = document.querySelectorAll('.tab-btn');
            const tabContents = document.querySelectorAll('.tab-content');

            tabButtons.forEach((button, index) => {
                button.addEventListener('click', () => {
                    tabButtons.forEach(btn => btn.classList.remove('text-red-600', 'border-red-600'));
                    tabContents.forEach(content => content.classList.add('hidden'));

                    button.classList.add('text-red-600', 'border-red-600');
                    tabContents[index].classList.remove('hidden');
                });
            });
        </script>

    </body>

    </html>















