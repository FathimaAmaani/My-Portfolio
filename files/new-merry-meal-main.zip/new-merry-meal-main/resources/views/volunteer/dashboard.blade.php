<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ config('app.name') }} - Volunteer Dashboard</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body class="font-sans text-gray-900 antialiased">
    <!-- Header Section -->
    <header class="bg-white shadow fixed w-full z-50">
        <nav class="container mx-auto px-6 py-3">
            <div class="flex justify-between items-center">
                <div class="flex items-center">
                    <a href="/" class="flex items-center">
                        <img src="{{ asset('images/merrymeals.png') }}" class="w-20 h-20" alt="Meals on Wheels Logo" />
                        <span class="ml-3 text-xl font-bold">Meals on Wheels</span>
                    </a>
                </div>

                <div class="hidden md:flex items-center space-x-8">
                    <a href="/about" class="text-gray-600 hover:text-gray-900">About Us</a>
                    <a href="/services" class="text-gray-600 hover:text-gray-900">Our Services</a>
                    <a href="/donate" class="text-gray-600 hover:text-gray-900">Donate</a>
                    @auth
                        <div class=" gap-3 flex items-center">
                            <div class=" border border-2 border-red-500 rounded-full w-[45px] h-[45px]"></div>
                            @if (Auth::user()->role == 'member')
                                <a href="{{ route('member.dashboard') }}"
                                    class="text-gray-600 hover:text-gray-900">{{ Auth::user()->name }}</a>
                            @elseif(Auth::user()->role == 'caregiver')
                                <a href="{{ route('caregiver.dashboard') }}"
                                    class="text-gray-600 hover:text-gray-900">{{ Auth::user()->name }}</a>
                            @elseif(Auth::user()->role == 'partner')
                                <a href="{{ route('partner.dashboard') }}"
                                    class="text-gray-600 hover:text-gray-900">{{ Auth::user()->name }}</a>
                            @elseif(Auth::user()->role == 'volunteer')
                                <a href="{{ route('volunteer.dashboard') }}"
                                    class="text-gray-600 hover:text-gray-900">{{ Auth::user()->name }}</a>
                            @elseif(Auth::user()->role == 'admin')
                                <a href="{{ route('admin.dashboard') }}"
                                    class="text-gray-600 hover:text-gray-900">{{ Auth::user()->name }}</a>
                            @endif

                            <form action="{{ route('logout') }}" method="POST" class="inline-block">
                                @csrf
                                <button type="submit"
                                    class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">Logout</button>
                            </form>
                        </div>
                    @else
                        <a href="{{ route('login') }}" class="text-gray-600 hover:text-gray-900">Login</a>
                        <a href="{{ route('register') }}"
                            class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">Join us</a>
                    @endauth
                </div>
            </div>
        </nav>
    </header>
    <!-- Session Status -->

    <div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100">
        <div class="pt-24">
            <!-- Tabs Navigation -->
            <div class="bg-white shadow-sm">
                <div class="container mx-auto px-6">
                    <div class="flex overflow-x-auto space-x-4 py-4">
                        <button
                            class="text-red-600 border-red-600 tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">Overview</button>
                        <button
                            class="tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">My
                            Profile</button>
                        <button
                            class="tab-btn px-4 py-2 text-gray-600 hover:text-red-600 font-medium border-b-2 border-transparent hover:border-red-600">Assigned
                            Deliveries</button>
                    </div>
                </div>
            </div>

            <div class="container mx-auto px-6 py-8 min-w-[1400px]">
                <!-- Overview Tab -->
                <div id="overview-tab" class="tab-content">
                    <!-- Header Section -->
                    <div class="flex items-center justify-between mb-8">
                        <h2 class="text-3xl font-bold tracking-tight">Volunteer Dashboard</h2>
                        <div class="bg-white p-2 rounded-lg shadow flex items-center">
                            <span class="text-sm text-gray-600">Last updated: 5 minutes ago</span>
                        </div>
                    </div>

                    <!-- Stats Cards -->
                    <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-3 mb-8">
                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <div class="flex justify-between items-center mb-4">
                                <h3 class="text-sm font-medium">Total Deliveries</h3>
                                <svg class="h-4 w-4 text-gray-500" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                                </svg>
                            </div>
                            <div class="text-2xl font-bold">{{ $deliveries->count() }}</div>
                            <span
                                class="inline-block px-2 py-1 mt-2 text-xs font-semibold text-white bg-green-500 rounded-full">Active</span>
                        </div>

                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <div class="flex justify-between items-center mb-4">
                                <h3 class="text-sm font-medium">Completed Deliveries</h3>
                                <svg class="h-4 w-4 text-gray-500" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div class="text-2xl font-bold">{{ $deliveries->where('status', 'Completed')->count() }}
                            </div>
                            <span
                                class="inline-block px-2 py-1 mt-2 text-xs font-semibold text-white bg-blue-500 rounded-full">Completed</span>
                        </div>

                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <div class="flex justify-between items-center mb-4">
                                <h3 class="text-sm font-medium">Current Status</h3>
                                <svg class="h-4 w-4 text-gray-500" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div class="text-2xl font-bold">{{ $volunteer->status }}</div>
                            <span
                                class="inline-block px-2 py-1 mt-2 text-xs font-semibold text-white 
                                {{ $volunteer->status === 'Available' ? 'bg-green-500' : 'bg-red-500' }} rounded-full">
                                {{ $volunteer->status }}
                            </span>
                        </div>
                    </div>

                    <!-- Recent Deliveries Chart -->
                    <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <h3 class="text-lg font-semibold mb-4">Delivery Statistics</h3>
                            <canvas id="deliveryStatsChart" width="400" height="300"></canvas>
                        </div>

                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <h3 class="text-lg font-semibold mb-4">Weekly Performance</h3>
                            <canvas id="weeklyPerformanceChart" width="400" height="300"></canvas>
                        </div>

                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <h3 class="text-lg font-semibold mb-4">Delivery Areas</h3>
                            <canvas id="deliveryAreasChart" width="400" height="300"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Profile Tab Content -->
                <div id="profile-tab" class="tab-content hidden">
                    <!-- Existing Profile Content -->
                    <!-- Status Update Form -->
                    <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                        <h3 class="text-xl font-bold mb-4">Update Availability Status</h3>
                        <form action="{{ route('volunteer.updateStatus') }}" method="POST"
                            class="flex items-center gap-4">
                            @csrf
                            <select name="status"
                                class="rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring focus:ring-red-200">
                                <option value="Available" {{ $volunteer->status === 'Available' ? 'selected' : '' }}>
                                    Available</option>
                                <option value="Unavailable"
                                    {{ $volunteer->status === 'Unavailable' ? 'selected' : '' }}>Unavailable</option>
                            </select>
                            <button type="submit"
                                class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition">
                                Update Status
                            </button>
                        </form>
                    </div>

                    <!-- Profile Information -->
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <h3 class="text-xl font-bold mb-6">Profile Information</h3>
                        <div class="grid md:grid-cols-2 gap-6">
                            <!-- Personal Information -->
                            <div>
                                <h4 class="text-lg font-semibold mb-4">Personal Details</h4>
                                <div class="space-y-3">
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Name:</span>
                                        <span class="font-medium">{{ $volunteer->user->name }}</span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Email:</span>
                                        <span class="font-medium">{{ $volunteer->user->email }}</span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Phone:</span>
                                        <span class="font-medium">{{ $volunteer->user->phone_number }}</span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Address:</span>
                                        <span class="font-medium">{{ $volunteer->user->address }}</span>
                                    </p>
                                </div>
                            </div>

                            <!-- Volunteer Information -->
                            <div>
                                <h4 class="text-lg font-semibold mb-4">Volunteer Details</h4>
                                <div class="space-y-3">
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Experience:</span>
                                        <span class="font-medium">{{ $volunteer->vol_experience }}</span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Availability:</span>
                                        <span class="font-medium">{{ $volunteer->vol_availability }}</span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-600">Rider License:</span>
                                        <span class="font-medium">{{ $volunteer->rider_license }}</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Deliveries Tab Content -->
                <div id="deliveries-tab" class="tab-content hidden">
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <h2 class="text-2xl font-bold mb-6">My Assigned Deliveries</h2>
                        <div class="space-y-6">
                            @forelse($deliveries as $delivery)
                                <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                                    <div class="flex justify-between items-start mb-4">
                                        <div>
                                            <h3 class="text-lg font-semibold">Delivery #{{ $delivery->id }}</h3>
                                            <p class="text-sm text-gray-500">Assigned on
                                                {{ $delivery->created_at->format('M d, Y') }}</p>
                                        </div>
                                        <span
                                            class="px-3 py-1 rounded-full text-sm font-semibold 
                                            {{ $delivery->status === 'Completed'
                                                ? 'bg-green-100 text-green-800'
                                                : ($delivery->status === 'In Progress'
                                                    ? 'bg-blue-100 text-blue-800'
                                                    : 'bg-yellow-100 text-yellow-800') }}">
                                            {{ $delivery->status }}
                                        </span>
                                    </div>

                                    <div class="grid md:grid-cols-2 gap-6">
                                        <div class="space-y-3">
                                            <div>
                                                <h4 class="text-sm font-medium text-gray-500">Meal Details</h4>
                                                <p class="font-medium">{{ $delivery->meal->name }}</p>
                                            </div>
                                            <div>
                                                <h4 class="text-sm font-medium text-gray-500">Member Information</h4>
                                                <p class="font-medium">{{ $delivery->member->user->name }}</p>
                                                <p class="text-sm text-gray-600">
                                                    {{ $delivery->member->user->phone_number }}</p>
                                                <p class="text-sm text-gray-600">
                                                    {{ $delivery->member->user->address }}</p>
                                            </div>
                                        </div>

                                        <div>
                                            <h4 class="text-sm font-medium text-gray-500 mb-2">Update Status</h4>
                                            <form
                                                action="{{ route('volunteer.updateDeliveryStatus', $delivery->id) }}"
                                                method="POST">
                                                @csrf
                                                <select name="status"
                                                    class="w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring focus:ring-red-200 mb-3">
                                                    <option value="Pending"
                                                        {{ $delivery->status === 'Pending' ? 'selected' : '' }}>Pending
                                                    </option>
                                                    <option value="In Progress"
                                                        {{ $delivery->status === 'In Progress' ? 'selected' : '' }}>In
                                                        Progress</option>
                                                    <option value="Completed"
                                                        {{ $delivery->status === 'Completed' ? 'selected' : '' }}>
                                                        Completed</option>
                                                </select>
                                                <button type="submit"
                                                    class="w-full bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition">
                                                    Update Status
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            @empty
                                <div class="text-center py-8 text-gray-500">
                                    No deliveries assigned yet.
                                </div>
                            @endforelse
                        </div>
                    </div>
                </div>

            </div>
        </div>


    </div>



    <footer class="bg-gray-800 text-white py-12">
        <div class="container mx-auto px-6">
            <div class="grid md:grid-cols-4 gap-8">
                <div>
                    <h3 class="text-xl font-semibold mb-4">About Us</h3>
                    <p class="text-gray-300">Meals on Wheels delivers nutritious meals to those in need,
                        bringing communities together through compassionate service.</p>
                </div>
                <div>
                    <h3 class="text-xl font-semibold mb-4">Quick Links</h3>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-300 hover:text-white transition">Volunteer</a>
                        </li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition">Donate</a>
                        </li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition">Partner With
                                Us</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition">Contact</a>
                        </li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-xl font-semibold mb-4">Contact Info</h3>
                    <ul class="space-y-2 text-gray-300">
                        <li>Phone: (555) 123-4567</li>
                        <li>Email: info@mealsonwheels.org</li>
                        <li>Address: 123 Care Street</li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-xl font-semibold mb-4">Follow Us</h3>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-300 hover:text-white transition">
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                                <path
                                    d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                            </svg>
                        </a>
                        <a href="#" class="text-gray-300 hover:text-white transition">
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                                <path
                                    d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
                            </svg>
                        </a>
                        <a href="#" class="text-gray-300 hover:text-white transition">
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                                <path
                                    d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.897 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.897-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
                <p>&copy; {{ date('Y') }} Meals on Wheels. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Tab switching functionality
        const tabButtons = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');

        tabButtons.forEach((button, index) => {
            button.addEventListener('click', () => {
                // Remove active states
                tabButtons.forEach(btn => btn.classList.remove('text-red-600', 'border-red-600'));
                tabContents.forEach(content => content.classList.add('hidden'));

                // Add active states
                button.classList.add('text-red-600', 'border-red-600');
                tabContents[index].classList.remove('hidden');
            });
        });

        // Charts
        const deliveryCtx = document.getElementById('deliveryStatsChart').getContext('2d');
        new Chart(deliveryCtx, {
            type: 'pie',
            data: {
                labels: ['Completed', 'In Progress', 'Pending'],
                datasets: [{
                    data: [
                        {{ $deliveries->where('status', 'Completed')->count() }},
                        {{ $deliveries->where('status', 'In Progress')->count() }},
                        {{ $deliveries->where('status', 'Pending')->count() }}
                    ],
                    backgroundColor: ['#10B981', '#3B82F6', '#F59E0B']
                }]
            }
        });

        const weeklyCtx = document.getElementById('weeklyPerformanceChart').getContext('2d');
        new Chart(weeklyCtx, {
            type: 'bar',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Deliveries',
                    data: [4, 3, 5, 2, 4, 6, 3],
                    backgroundColor: '#EF4444'
                }]
            }
        });

        const areasCtx = document.getElementById('deliveryAreasChart').getContext('2d');
        new Chart(areasCtx, {
            type: 'radar',
            data: {
                labels: ['North', 'South', 'East', 'West', 'Central'],
                datasets: [{
                    label: 'Coverage',
                    data: [65, 75, 70, 80, 60],
                    backgroundColor: 'rgba(239, 68, 68, 0.2)',
                    borderColor: '#EF4444',
                    pointBackgroundColor: '#EF4444'
                }]
            },
            options: {
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    </script>
</body>

</html>
