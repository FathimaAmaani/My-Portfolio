<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\CaregiverController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\PartnerController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\VolunteerController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('home');
});
Route::get('/about', function () {
    return view('about');
});
Route::get('/donate', function () {
    return view('donate');
});
Route::get('/services', function () {
    return view('services');
});

Route::get('/dashboard', function () {
    if (Auth::user()->role === 'admin') {
        return redirect()->route('admin.dashboard');
    } elseif (Auth::user()->role === 'member') {
        return redirect()->route('member.dashboard');
    } elseif (Auth::user()->role === 'caregiver') {
        return redirect()->route('caregiver.dashboard');
    } elseif (Auth::user()->role === 'partner') {
        return redirect()->route('partner.dashboard');
    } elseif (Auth::user()->role === 'volunteer') {
        return redirect()->route('volunteer.dashboard');
    }
    // return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard/member', [MemberController::class, 'index'])->name('member.dashboard');
    Route::get('/dashboard/caregiver', [CaregiverController::class, 'index'])->name('caregiver.dashboard');
    Route::get('/dashboard/partner', [PartnerController::class, 'index'])->name('partner.dashboard');
    Route::get('/dashboard/volunteer', [VolunteerController::class, 'index'])->name('volunteer.dashboard');
    Route::post('/volunteer/update-status', [VolunteerController::class, 'updateStatus'])->name('volunteer.updateStatus');
    Route::post('/volunteer/delivery/{id}/update-status', [VolunteerController::class, 'updateDeliveryStatus'])->name('volunteer.updateDeliveryStatus');
    Route::get('/dashboard/admin', [AdminController::class, 'index'])->name('admin.dashboard');
    Route::post('/admin/meals', [AdminController::class, 'storeMeal'])->name('admin.meals.store');
    Route::get('/admin/meals/{meal}/edit', [AdminController::class, 'editMeal'])->name('admin.meals.edit');
    Route::put('/admin/meals/{meal}', [AdminController::class, 'updateMeal'])->name('admin.meals.update');
    Route::delete('/admin/meals/{meal}', [AdminController::class, 'destroyMeal'])->name('admin.meals.destroy');
    Route::post('/admin/deliveries', [AdminController::class, 'storeDelivery'])->name('admin.deliveries.store');
    Route::post('/admin/assign-caregiver', [AdminController::class, 'assignCaregiver'])->name('admin.assignCaregiver');
    Route::post('/admin/update-member-location', [AdminController::class, 'updateMemberLocation'])
        ->name('admin.update-member-location');


});



Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__ . '/auth.php';
