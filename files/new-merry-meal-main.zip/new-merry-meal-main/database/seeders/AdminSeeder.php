<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'name' => 'Admin User', // Set the admin's name
            'email' => 'admin@example.com', // Set the admin's email
            'password' => Hash::make('password123'), // Set a secure password
            'gender' => 'male', // Set the admin's gender
            'age' => 30, // Set the admin's age
            'address' => '123 Admin Street', // Set the admin's address
            'phone_number' => '1234567890', // Set the admin's phone number
            'role' => 'admin', // Assuming you have a `role` column in the `users` table
        ]);
    }
}
