<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Caregiver extends Model
{
    protected $fillable = [
        'user_id',
        'specialization',
        'experience',
        'availability',
        'assigned_member_id',
    ];

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function assignedMember(){
        return $this->belongsTo(Member::class, 'assigned_member_id');
    }
}
