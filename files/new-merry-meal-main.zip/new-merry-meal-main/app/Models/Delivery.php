<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Delivery extends Model
{
    use HasFactory;

    protected $fillable = [
        'volunteer_id',
        'member_id',
        'meal_id',
        'status'
    ];

    public function volunteer()
    {
        return $this->belongsTo(Volunteer::class);
    }

    public function member()
    {
        return $this->belongsTo(Member::class);
    }

    public function meal()
    {
        return $this->belongsTo(Meal::class);
    }
}
