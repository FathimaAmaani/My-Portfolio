<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Partner extends Model
{
    protected $fillable = [
        'user_id',
        'org_name',
        'org_url',
        'partnership_term',
    ];

    public function user(){
        return $this->belongsTo(User::class);
    }
}
