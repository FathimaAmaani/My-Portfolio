<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Meal extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'dietary_restrictions',
        'quantity'
    ];

    protected $casts = [
        'dietary_restrictions' => 'array'
    ];
}
