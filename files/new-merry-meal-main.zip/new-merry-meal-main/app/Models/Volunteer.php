<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Volunteer extends Model
{
    protected $fillable = [
        'user_id',
        'vol_experience',
        'vol_availability',
        'status',
        'rider_license',
    ];

    public function user(){
        return $this->belongsTo(User::class);
    }
}
