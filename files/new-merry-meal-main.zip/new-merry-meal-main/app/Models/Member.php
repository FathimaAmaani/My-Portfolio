<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    protected $fillable = [
        'user_id',
        'medical_condition',
        'allergies',
        'dietary_restrictions',
        'meal_status',
    ];

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function caregiver()
    {
        return $this->hasOne(Caregiver::class, 'assigned_member_id');
    }
   
}
