<?php

namespace App\Http\Controllers;

use App\Models\Delivery;
use App\Models\Volunteer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class VolunteerController extends Controller
{
    public function index()
    {
        $volunteer = Auth::user()->volunteer;
        $deliveries = Delivery::where('volunteer_id', $volunteer->id)
            ->with(['meal', 'member.user'])
            ->orderBy('created_at', 'desc')
            ->get();

        return view('volunteer.dashboard', compact('volunteer', 'deliveries'));
    }

    public function updateStatus(Request $request)
    {
        $request->validate([
            'status' => 'required|in:Available,Unavailable'
        ]);

        $volunteer = Auth::user()->volunteer;
        $volunteer->status = $request->status;
        $volunteer->save();

        return redirect()->back()->with('success', 'Status updated successfully');
    }

    public function updateDeliveryStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:Pending,In Progress,Completed'
        ]);

        $delivery = Delivery::findOrFail($id);
        $delivery->status = $request->status;
        $delivery->save();

        return redirect()->back()->with('success', 'Delivery status updated successfully');
    }
}
