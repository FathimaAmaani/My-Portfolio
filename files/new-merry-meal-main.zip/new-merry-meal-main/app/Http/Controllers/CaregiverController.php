<?php

namespace App\Http\Controllers;

use App\Models\Caregiver;
use App\Models\Delivery;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CaregiverController extends Controller
{
    public function index()
    {
        $caregiver = Auth::user()->caregiver;
        $deliveries = [];

        if ($caregiver->assignedMember) {
            $deliveries = Delivery::where('member_id', $caregiver->assignedMember->id)
                ->with(['meal', 'volunteer.user'])
                ->orderBy('created_at', 'desc')
                ->get();
        }

        return view('caregiver.dashboard', compact('caregiver', 'deliveries'));
    }
}
