<?php

namespace App\Http\Controllers;

use App\Models\Caregiver;
use App\Models\Delivery;
use App\Models\Meal;
use App\Models\Member;
use App\Models\Partner;
use App\Models\User;
use App\Models\Volunteer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function index()
    {
        $usersByRole = [
            'member' => User::where('role', 'member')->get(),
            'caregiver' => User::where('role', 'caregiver')->get(),
            'partner' => User::where('role', 'partner')->get(),
            'volunteer' => User::where('role', 'volunteer')->get(),
        ];

        $meals = Meal::all();
        $deliveries = Delivery::with(['volunteer.user', 'member.user', 'meal'])->get();
        $volunteers = Volunteer::where('status', 'Available')->get();
        $members = Member::all();
        $unassignedMembers = Member::whereDoesntHave('caregiver')->get();
        $availableCaregivers = Caregiver::where('availability', 'Available')->get();
        if (Auth::user()->role === 'admin') {
            // Return admin dashboard view or data
            return view('admin.dashboard', compact('usersByRole', 'meals', 'deliveries', 'volunteers', 'members', 'unassignedMembers', 'availableCaregivers'));
        } else {
            // Abort with 403 Forbidden
            abort(403, 'Unauthorized');
        }
    }

    public function storeMeal(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'dietary_restrictions' => 'array',
            'quantity' => 'required|integer|min:0',
            'status' => 'required|in:hot,frozen'
        ]);

        $meal = Meal::create([
            'name' => $validated['name'],
            'description' => $validated['description'],
            'dietary_restrictions' => $validated['dietary_restrictions'] ?? [],
            'quantity' => $validated['quantity'],
            'status' => $validated['status']
        ]);

        return redirect()->back()->with('success', 'Meal added successfully!');
    }

    public function editMeal(Meal $meal)
    {
        return response()->json($meal);
    }

    public function updateMeal(Request $request, Meal $meal)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'dietary_restrictions' => 'array',
            'quantity' => 'required|integer|min:0',
            'status' => 'required|in:hot,frozen'
        ]);

        $meal->update($validated);

        return redirect()->back()->with('success', 'Meal updated successfully!');
    }

    public function destroyMeal(Meal $meal)
    {
        $meal->delete();
        return redirect()->back()->with('success', 'Meal deleted successfully!');
    }

    public function storeDelivery(Request $request)
    {
        $validated = $request->validate([
            'volunteer_id' => 'required|exists:volunteers,id',
            'member_id' => 'required|exists:members,id',
            'meal_id' => 'required|exists:meals,id',
        ]);

        Delivery::create([
            'volunteer_id' => $validated['volunteer_id'],
            'member_id' => $validated['member_id'],
            'meal_id' => $validated['meal_id'],
            'status' => 'Pending'
        ]);

        return redirect()->back()->with('success', 'Delivery assigned successfully!');
    }

    public function assignCaregiver(Request $request)
    {
        $request->validate([
            'member_id' => 'required|exists:members,id',
            'caregiver_id' => 'required|exists:caregivers,id'
        ]);

        $caregiver = Caregiver::find($request->caregiver_id);
        $caregiver->assigned_member_id = $request->member_id;
        $caregiver->save();

        return redirect()->back()->with('success', 'Caregiver assigned successfully');
    }



}
