<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Caregiver;
use App\Models\Member;
use App\Models\Partner;
use App\Models\User;
use App\Models\Volunteer;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Illuminate\View\View;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(): View
    {
        return view('auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        // dd($request->all());
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'confirmed', Rules\Password::defaults()
            ->mixedCase()
            ->numbers()
            ->symbols()
            ->min(8)],
            'gender' => 'required',
            'age' => 'required|integer',
            'address' => ['required', 'string', 'max:255'],
            'phone_number' => ['required', 'string', 'min:10', 'max:15'],
            'role' => ['required', 'string', 'in:member,volunteer,partner,caregiver'],
            'latitude' => 'required_if:role,member',
            'longitude' => 'required_if:role,member',
        ], [
            'name.required' => 'Please enter your name',
            'email.required' => 'Please enter your email address',
            'email.email' => 'Please enter a valid email address',
            'email.unique' => 'This email is already registered',
            'password.required' => 'Please enter a password',
            'password.confirmed' => 'Passwords do not match',
            'password.min' => 'Password must be at least 8 characters',
            'role.required' => 'Please select your role',
            'phone_number.required' => 'Please enter your phone number',
            'address.required' => 'Please enter your address',
        ]);

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => bcrypt($validated['password']),
            'gender' => $validated['gender'],
            'age' => $validated['age'],
            'address' => $validated['address'],
            'phone_number' => $validated['phone_number'],
            'role' => $validated['role'],
        ]);

        if ($user->role === 'member') {
            // Calculate distance and set meal_status
            $adminLocation = ['lat' => 6.866514, 'lng' => 96.108544];
            $memberLocation = ['lat' => $request->latitude, 'lng' => $request->longitude];

            $distance = $this->calculateDistance($adminLocation, $memberLocation);
            $mealStatus = $distance <= 10 ? 'hot' : 'frozen';

            Member::create([
                'user_id' => $user->id,
                'medical_condition' => $request->medical_condition,
                'allergies' => $request->allergies,
                'dietary_restrictions' => $request->dietary_restrictions,
                'meal_status' => $mealStatus
            ]);
        } elseif ($user->role === 'caregiver') {
            Caregiver::create([
                'user_id' => $user->id,
                'experience' => $request->experience,
                'availability' => $request->availability,
                'specialization' => $request->specialization,
            ]);
        } elseif ($user->role === 'partner') {
            Partner::create([
                'user_id' => $user->id,
                'org_name' => $request->org_name,
                'org_url' => $request->org_url,
                'partnership_term' => $request->partnership_term,
            ]);
        } elseif ($user->role === 'volunteer') {
            Volunteer::create([
                'user_id' => $user->id,
                'vol_experience' => $request->vol_experience,
                'vol_availability' => $request->vol_availability,
                'status' => 'Available',
                'rider_license' => $request->rider_license,
            ]);
        }

        event(new Registered($user));
        Auth::login($user);

        if ($user->role === 'member') {
            return redirect()->route('member.dashboard');
        } elseif ($user->role === 'caregiver') {
            return redirect()->route('caregiver.dashboard');
        } elseif ($user->role === 'partner') {
            return redirect()->route('partner.dashboard');
        } elseif ($user->role === 'volunteer') {
            return redirect()->route('volunteer.dashboard');
        } elseif ($user->role === 'admin') {
            return redirect()->route('admin.dashboard');
        }
    }

    private function calculateDistance($point1, $point2)
    {
        $earthRadius = 6371; // Earth's radius in kilometers

        $lat1 = deg2rad($point1['lat']);
        $lng1 = deg2rad($point1['lng']);
        $lat2 = deg2rad($point2['lat']);
        $lng2 = deg2rad($point2['lng']);

        $dlat = $lat2 - $lat1;
        $dlng = $lng2 - $lng1;

        $a = sin($dlat / 2) * sin($dlat / 2) + cos($lat1) * cos($lat2) * sin($dlng / 2) * sin($dlng / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earthRadius * $c;
    }
}
