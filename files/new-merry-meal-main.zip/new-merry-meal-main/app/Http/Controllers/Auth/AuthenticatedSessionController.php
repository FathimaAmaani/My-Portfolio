<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): View
    {
        return view('auth.login');
    }

    /**
     * Handle an incoming authentication request.
     */
    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();

        $request->session()->regenerate();

        $role = Auth::user()->role;

        switch ($role) {
        case 'member':
            return redirect()->route('member.dashboard');
        case 'caregiver':
            return redirect()->route('caregiver.dashboard');
        case 'partner':
            return redirect()->route('partner.dashboard');
        case 'volunteer':
            return redirect()->route('volunteer.dashboard');
        case 'admin':
            return redirect()->route('admin.dashboard');
        default:
            // Fallback for unexpected roles
            return redirect()->route('dashboard')->withErrors('Invalid role');
        }
    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
