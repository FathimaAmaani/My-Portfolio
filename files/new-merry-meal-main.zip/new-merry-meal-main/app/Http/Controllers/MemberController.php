<?php

namespace App\Http\Controllers;

use App\Models\Caregiver;
use App\Models\Delivery;
use App\Models\Meal;
use App\Models\Member;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MemberController extends Controller
{
    public function index(){
        $member = Auth::user()->member;
        $meals = Meal::all();
        $deliveries = Delivery::where('member_id', $member->id)
            ->with(['meal', 'volunteer.user'])
            ->orderBy('created_at', 'desc')
            ->get();
        
        return view('member.dashboard', compact('member', 'meals', 'deliveries'));
    }
}
