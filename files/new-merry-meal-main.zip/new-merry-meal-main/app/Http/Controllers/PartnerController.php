<?php

namespace App\Http\Controllers;

use App\Models\Meal;
use App\Models\Partner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PartnerController extends Controller
{
    public function index()
    {
        $partner = Auth::user()->partner;
        $meals = Meal::all();
        return view('partner.dashboard', compact('partner', 'meals'));
    }
}
