<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class RoleMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string  $role
     * @return mixed
     */
    public function handle(Request $request, Closure $next, $role)
    {
        // Ensure the user is authenticated and their role matches
        if (Auth::check() && Auth::user()->role === $role) {
            return $next($request);
        }

        // Optional: Return unauthorized response if role doesn't match
        abort(403, 'Unauthorized');
    }
}
