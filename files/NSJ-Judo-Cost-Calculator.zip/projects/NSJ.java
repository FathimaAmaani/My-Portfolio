
/*
* NSJ */

import java.util.*;
public class NSJ{
    private final Scanner input=new Scanner(System.in);
    private double cal;
    private double competitionCharges;
    private double totCharge;
    private String name;

    public static void main(String[] args){ //where all my code is executed in computer
        NSJ log=new NSJ();
        NSJ plans=new NSJ();
         System.out.println("Hello Welcome");
        log.login();
        plans.trainingPlans();
    }
        //login to the system
        void login(){
            System.out.println("Have you registered? (yes/no)"); // system ask whether user was registered or not
            String log = input.next();
            while(!log.equalsIgnoreCase("yes") && !log.equals("no")
                    && !log.equals("NO") && !log.equals("nO") && !log.equals("No")){
                System.out.println("invalid input please Enter yes or no");
                log =input.next();
            }
        if (log.equalsIgnoreCase("yes")){
            System.out.println("type your name");
          name=input.next();

          while (!name.matches("[a-zA-Z]+")){
            System.out.println("please enter a valid name");
            name=input.next();
          }
            System.out.println("you can continue "+ name);
            privateTuition();
            
             }// if not registered the system ask to register by giving the name
             else {
                System.out.println("Register your name first");
        System.out.println("Enter your name");
         name=input.next();
         while(!name.matches("[a-zA-Z]+")){
            System.out.println("please enter a valid name");
           name=input.next();
          }

        System.out.println(name+" you have completed registration");
     privateTuition();
         // go to the system after registration 
             }
    
    }

    //asking for private coach
 void privateTuition(){
    System.out.println("Do you need private tuition?(yes/no)");
    String privateCoach=input.next();

    while(!privateCoach.equalsIgnoreCase("yes")
            && !privateCoach.equals("NO") && !privateCoach.equals("no") && !privateCoach.equals("No") && !privateCoach.equals("nO")){
        System.out.println("invalid input please Enter yes or no");
        privateCoach=input.next();
    }

      if (privateCoach.equalsIgnoreCase("yes")){
        System.out.println("Private tuition(per hour) - $9.00");
        
        //input validation
          int noOfHours;
          while(true){
            System.out.println("Enter the number of hours needed for private couch per week");
            if(input.hasNextInt()){
                noOfHours =input.nextInt();
                if(noOfHours <=0){
                    System.out.println("Invalid input please enter a positive integer");
                }else if(noOfHours >6){
                    System.out.println("Athletes can receive a maximum of five hours private coaching a week "+"please re-enter the no of hours");
                }else {
                    break;
                }

            } else {
                System.out.println("Invalid input please enter a positive integer");
                input.next();            }
        }
    
         cal= noOfHours *9*4;
              // entering the training plan after displaying all the plans
          System.out.println("Enter your training plan (Beginner/Intermediate/Elite)");
         String plan=input.next();

        while(!plan.equalsIgnoreCase("beginner")
                && !plan.equalsIgnoreCase("intermediate")
                && !plan.equalsIgnoreCase("elite")){
        System.out.println("invalid input please enter Beginner/intermediate/elite");
         plan=input.next();
     }
       
          if(plan.equalsIgnoreCase("Beginner")){
            System.out.println("Hello "+name);
             System.out.println("you are not eligible for competitions");
              cal= noOfHours *4*9;
             System.out.println("your monthly payment is "+"$"+cal);
             System.exit(0); //Beginner cano not allow for competitions
          }
          else { 
             charge();
             cal= noOfHours *4*9;  //calculate monthly charges accordingly
             totCharge= competitionCharges+cal;
             System.out.println("your monthly cost is "+ cal);
            System.out.println("you total monthly cost is "+"$"+ totCharge);
            System.exit(0);
          }
          
    } else {
        System.out.println("Then go to other options"); //if not interest in private coach go for other options
        trainingPlans();
    }
}
 void charge(){ //contains the details for competitors
    System.out.println("Congratulations! you are eligible for competitions ");
             weightCategories();
             System.out.println("Entry fee per competition is $22.00");

           while(true){
            System.out.println("Enter the number of competitions");
            if(input.hasNextInt()){
                int noOfComps=input.nextInt();
                if(noOfComps<0){
                    System.out.println("Invalid input please Enter a positive integer");
                }else{
                     competitionCharges=noOfComps*22;
                     System.out.println("Hello "+name);
                     System.out.println("you have entered "+noOfComps+" Competitions" );
                     System.out.println("your charges for competitions is "+"$"+ competitionCharges);
                     System.out.println("competitions are held on second Saturday of each month");
                      break;

                }
            } else{
                System.out.println("Invalid input please enter a correct value");
                input.next(); 

            }
            
           }          
 }
 void competitions(){
        
        System.out.println("Enter your training plan (Beginner/Intermediate/Elite)");
        String plan=input.next();
    
        if(plan.equalsIgnoreCase("Beginner")){ //checks for exceptions for beginners
            System.out.println("Hello "+name);
            System.out.println("you are not eligible to go to competition");
            cal=25*4;
            System.out.println("your monthly training cost is "+"$"+cal);
            System.exit(0);
        }
        else if(plan.equalsIgnoreCase("Intermediate")){ //details for intermediates
            charge();
            cal=30*4;
             totCharge= competitionCharges+cal;
             System.out.println("your monthly training cost is "+"$"+ cal);
            System.out.println("you total monthly cost is "+"$"+ totCharge);
            System.exit(0);
        } 
        else if(plan.equalsIgnoreCase("elite")){ 

            charge(); //details for elite
            cal=35*4;
             totCharge= competitionCharges+cal;
             System.out.println("your monthly training cost is "+"$"+ cal);
        System.out.println("you total monthly cost is "+"$"+ totCharge);
        System.exit(0);
         
        } else{
            System.out.println("you have entered an invalid Training plan");
            competitions();

        }
    }

    void trainingPlans(){ //containing the training plans to be display
        String [][] planTable={{"Beginner (2 sessions per week)-weekly fees","$25.00"},
        {"Intermediate(3 sessions per week)-weekly fees","$30.00"},
        {"Elite (5 sessions per week)-weekly fees","$35.00"}};
        for (String[] strings : planTable) {
            for (String string : strings) {
                System.out.println(string + " ");

            }
        }
        competitions();
    }
 
    void weightCategories(){ //containing the weight categories to be display
        while(true){
            System.out.println("Enter your weight");
          if(input.hasNextInt()){
              int weight = input.nextInt();
              if(weight <=0){
                System.out.println("Invalid weight please Enter a valid weight");
             } else if(weight >100){
                System.out.println("your are under heavy weight");
                break;
             } else if(weight >90) {
                System.out.println("you are under light-heavy weight");
                break;
             } else if(weight >80) {
                System.out.println("you are under Middle-weight");
                break;
             } else if(weight >73) {
                System.out.println("you are under light Middle-weight");
                break;
             } else if(weight >66) {
                System.out.println("you are under light-weight");
                break;
             } else {
                System.out.println("you are under  fly-weight");
                break;
             }
               
          } else {
            System.out.println("Invalid input please Enter a valid Weight");
            input.next();
          }

        }    
    }
  
// done..!
}