<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
         <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Manage Bids') }}
         </h2>
         <a href="{{ route('admin.dashboard') }}" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md text-sm">
            Back to Dashboard
         </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    @if(session('success'))
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
                            {{ session('success') }}
                        </div>
                    @endif

                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white">
                            <thead class="bg-gray-100">
                                <tr>
                                    <th class="px-6 py-3 border-b border-gray-200 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Car Details</th>
                                    <th class="px-6 py-3 border-b border-gray-200 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Bidder</th>
                                    <th class="px-6 py-3 border-b border-gray-200 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Bid Amount</th>
                                    <th class="px-6 py-3 border-b border-gray-200 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                    <th class="px-6 py-3 border-b border-gray-200 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                @foreach($bids as $bid)
                                <tr>
                                    <td class="px-6 py-4">
                                        <div class="flex items-center">
                                            <div>
                                                <div class="text-sm font-medium text-gray-900">
                                                    {{ $bid->car->make }} {{ $bid->car->model }}
                                                </div>
                                                <div class="text-sm text-gray-500">
                                                    Year: {{ $bid->car->year }}
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900">{{ $bid->user->name }}</div>
                                        <div class="text-sm text-gray-500">{{ $bid->user->email }}</div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm font-medium text-gray-900">
                                            ${{ number_format($bid->amount, 2) }}
                                        </div>
                                        <div class="text-xs text-gray-500">
                                            {{ $bid->created_at->format('M d, Y H:i') }}
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                            {{ $bid->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                               ($bid->status === 'accepted' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800') }}">
                                            {{ ucfirst($bid->status) }}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm">
                                        @if($bid->status === 'pending')
                                            <div class="flex flex-col space-y-2">
                                                <form action="{{ route('admin.bids.update.status', $bid->id) }}" method="POST">
                                                    @csrf
                                                    <button type="submit" name="status" value="accepted" 
                                                        class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded-md text-sm w-full mb-2">
                                                        Accept Bid
                                                    </button>
                                                    <button type="submit" name="status" value="rejected" 
                                                        class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-sm w-full">
                                                        Reject Bid
                                                    </button>
                                                </form>
                                            </div>
                                        @else
                                            <form action="{{ route('admin.bids.update.status', $bid->id) }}" method="POST">
                                                @csrf
                                                <button type="submit" name="status" value="pending" 
                                                    class="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded-md text-sm w-full">
                                                    Undo {{ ucfirst($bid->status) }}
                                                </button>
                                            </form>
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 