<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
         <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Manage Test Drives') }}
         </h2>
         <a href="{{ route('admin.dashboard') }}" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md text-sm">
            Back to Dashboard
         </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    @if(session('success'))
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
                            {{ session('success') }}
                        </div>
                    @endif

                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white">
                            <thead class="bg-gray-100">
                                <tr>
                                    <th class="px-6 py-3 border-b text-left text-xs font-medium text-gray-500 uppercase">User</th>
                                    <th class="px-6 py-3 border-b text-left text-xs font-medium text-gray-500 uppercase">Car</th>
                                    <th class="px-6 py-3 border-b text-left text-xs font-medium text-gray-500 uppercase">Scheduled At</th>
                                    <th class="px-6 py-3 border-b text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                    <th class="px-6 py-3 border-b text-left text-xs font-medium text-gray-500 uppercase">Notes</th>
                                    <th class="px-6 py-3 border-b text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                @foreach($testDrives as $testDrive)
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-900">{{ $testDrive->user->name }}</div>
                                            <div class="text-sm text-gray-500">{{ $testDrive->user->email }}</div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-900">{{ $testDrive->car->make }} {{ $testDrive->car->model }}</div>
                                            <div class="text-sm text-gray-500">${{ number_format($testDrive->car->price) }}</div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-900">
                                                {{ $testDrive->scheduled_at->format('M d, Y') }}
                                            </div>
                                            <div class="text-sm text-gray-500">
                                                {{ $testDrive->scheduled_at->format('h:i A') }}
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                {{ $testDrive->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : '' }}
                                                {{ $testDrive->status === 'approved' ? 'bg-green-100 text-green-800' : '' }}
                                                {{ $testDrive->status === 'rejected' ? 'bg-red-100 text-red-800' : '' }}">
                                                {{ ucfirst($testDrive->status) }}
                                            </span>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="text-sm text-gray-900">{{ $testDrive->notes ?? 'No notes' }}</div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                                            @if($testDrive->status === 'pending')
                                                <form action="{{ route('admin.cars.test-drives.update', $testDrive->id) }}" method="POST" class="inline">
                                                    @csrf
                                                    @method('PATCH')
                                                    <button type="submit" name="status" value="approved" 
                                                        class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded-md mr-2">
                                                        Approve
                                                    </button>
                                                    <button type="submit" name="status" value="rejected" 
                                                        class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md">
                                                        Reject
                                                    </button>
                                                </form>
                                            @else
                                                <form action="{{ route('admin.cars.test-drives.update', $testDrive->id) }}" method="POST" class="inline">
                                                    @csrf
                                                    @method('PATCH')
                                                    <button type="submit" name="status" value="pending" 
                                                        class="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded-md">
                                                        Undo {{ ucfirst($testDrive->status) }}
                                                    </button>
                                                </form>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 