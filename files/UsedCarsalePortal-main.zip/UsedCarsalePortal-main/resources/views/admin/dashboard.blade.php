<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Admin Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 flex">
            <!-- Sidebar -->
            <div class="bg-gray-800 text-white w-64 min-h-screen py-4 px-3 flex-shrink-0">
                <h2 class="text-2xl font-semibold mb-6">Admin Panel</h2>
                <nav class="space-y-2">
                    <a href="{{ route('admin.users') }}" 
                        class="block py-2 px-4 rounded hover:bg-gray-700 {{ request()->routeIs('admin.users') ? 'bg-gray-700' : '' }}">
                        Manage Users
                    </a>
                    <a href="{{ route('admin.cars') }}" 
                        class="block py-2 px-4 rounded hover:bg-gray-700 {{ request()->routeIs('admin.cars') ? 'bg-gray-700' : '' }}">
                        Manage Cars
                    </a>
                    <a href="{{ route('admin.test-drives') }}" 
                        class="block py-2 px-4 rounded hover:bg-gray-700 {{ request()->routeIs('admin.test-drives') ? 'bg-gray-700' : '' }}">
                        Test Drive Schedules
                    </a>
                    <a href="{{ route('admin.bids') }}" 

                        class="block py-2 px-4 rounded hover:bg-gray-700 {{ request()->routeIs('admin.bids') ? 'bg-gray-700' : '' }}">
                        Manage Bids
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="flex-1 ml-4">
                <!-- Statistics Cards -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                    <!-- Total Users Card -->
                    <a href="{{ route('admin.users') }}" class="block">
                        <div class="bg-white rounded-lg shadow-md p-6 hover:bg-gray-50 transition duration-150">
                            <div class="flex items-center">
                                <div class="p-3 rounded-full bg-blue-500 bg-opacity-20">
                                    <svg class="w-8 h-8 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                                    </svg>
                                </div>
                                <div class="ml-4">
                                    <h2 class="text-gray-600 text-sm">Total Users</h2>
                                    <p class="text-2xl font-semibold text-gray-800">{{ $users->where('is_admin', false)->where('is_test_user', false)->count() }}</p>
                                </div>
                            </div>
                        </div>
                    </a>

                    <!-- Active Cars Card -->
                <a href="{{ route('admin.cars.active') }}" class="block">
                    <div class="bg-white rounded-lg shadow-md p-6 hover:bg-gray-50 transition duration-150">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-green-500 bg-opacity-20">
                                <svg class="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <h2 class="text-gray-600 text-sm">Active Cars</h2>
                                <p class="text-2xl font-semibold text-gray-800">{{ $activeCars }}</p>
                            </div>
                        </div>
                    </div>
                </a>

                    <!-- Deactivated Cars Card -->
                <a href="{{ route('admin.cars.deactivated') }}" class="block">
                    <div class="bg-white rounded-lg shadow-md p-6 hover:bg-gray-50 transition duration-150">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-red-500 bg-opacity-20">
                                <svg class="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <h2 class="text-gray-600 text-sm">Deactivated Cars</h2>
                                <p class="text-2xl font-semibold text-gray-800">{{ $deactiveCars }}</p>
                            </div>
                        </div>
                    </div>
                </a>

                    <!-- Pending Bids Card -->
                    <a href="{{ route('admin.bids') }}" class="block">

                        <div class="bg-white rounded-lg shadow-md p-6 hover:bg-gray-50 transition duration-150">
                            <div class="flex items-center">
                                <div class="p-3 rounded-full bg-purple-500 bg-opacity-20">
                                    <svg class="w-8 h-8 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                </div>
                                <div class="ml-4">
                                    <h2 class="text-gray-600 text-sm">Bids</h2>
                                    <p class="text-2xl font-semibold text-gray-800">{{ $Bids->count()}}</p>
                                </div>
                            </div>
                        </div>
                    </a>

                    <!-- Test Drive Requests Card -->
                    <a href="{{ route('admin.test-drives') }}" class="block">
                        <div class="bg-white rounded-lg shadow-md p-6 hover:bg-gray-50 transition duration-150">
                            <div class="flex items-center">
                                <div class="p-3 rounded-full bg-indigo-500 bg-opacity-20">
                                    <svg class="w-8 h-8 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                    </svg>
                                </div>
                                <div class="ml-4">
                                    <h2 class="text-gray-600 text-sm">Test Drive Requests</h2>
                                    <p class="text-2xl font-semibold text-gray-800">{{ $TestDrives->count() }}</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <!-- Recent Activity -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <!-- Recent Bids -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-4">Recent Bids</h3>
                        <div class="space-y-4">
                            @foreach($recentBids as $bid)
                            <div class="border-b pb-3">
                                <p class="text-sm text-gray-600">
                                    {{ $bid->user->name }} - ${{ number_format($bid->amount) }}
                                </p>
                                <p class="text-xs text-gray-500">{{ $bid->created_at->diffForHumans() }}</p>
                            </div>
                            @endforeach
                        </div>
                    </div>

                    <!-- Recent Test Drive Requests -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-4">Recent Test Drive Requests</h3>
                        <div class="space-y-4">
                            @foreach($recentTestDrives as $testDrive)
                            <div class="border-b pb-3">
                                <p class="text-sm text-gray-600">
                                    {{ $testDrive->user->name }} - {{ $testDrive->car->make }} {{ $testDrive->car->model }}
                                </p>
                                <p class="text-xs text-gray-500">{{ $testDrive->created_at->diffForHumans() }}</p>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
