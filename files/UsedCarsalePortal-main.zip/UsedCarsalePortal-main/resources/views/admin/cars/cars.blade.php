<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Manage Cars') }}
            </h2>
            <a href="{{ route('admin.dashboard') }}" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md text-sm">
                Back to Dashboard
            </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            @if(session('success'))
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
                    {{ session('success') }}
                </div>
            @endif

            <div class="bg-gray-300 shadow-md rounded-lg mb-6">
                <div class="p-4 ">
                    <h3 class="text-lg font-bold mb-4">Active Cars</h3>
                    <div class="space-y-4">
                        @foreach($activeCars as $car)
                            <div class="bg-white border border-black rounded-lg  pb-2 flex items-center">

                                <div class="w-1/2">
                                    <h4 class="font-bold">{{ $car->title }}</h4>
                                    <p>Make: {{ $car->make }}</p>
                                    <p>Model: {{ $car->model }}</p>
                                    <p>Price: ${{ number_format($car->price, 2) }}</p>
                                    <p>Status: 
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                            Active
                                        </span>
                                    </p>
                                    <div class="mt-2 flex space-x-2">
                                        <a href="{{ route('cars.edit', $car->id) }}" class="bg-purple-500 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded">
                                            Edit
                                        </a>
                                        <button onclick="showCarDetails({{ $car->id }})" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md text-sm">
                                            View Details
                                        </button>
                                        <form action="{{ route('admin.cars.toggle-status', $car->id) }}" method="POST" class="inline">
                                            @csrf
                                            @method('PUT')
                                            <button type="submit" class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-md text-sm">
                                                Deactivate
                                            </button>
                                        </form>
                                        <form action="{{ route('admin.cars.delete', $car->id) }}" method="POST" class="inline"
                                            onsubmit="return confirm('Are you sure you want to permanently delete this car? This action cannot be undone.');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md text-sm">
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                <div class="w-1/2">
                                    <img src="{{ $car->photos->first() ? Storage::url($car->photos->first()->path) : asset('images/no-image.png') }}" 
                                         alt="{{ $car->title }}" 
                                         class="w-full h-48 object-cover rounded-lg">
                                </div>
                            </div>
                        @endforeach
                    </div>
                    @if($activeCars->isEmpty())
                        <p class="text-gray-600">No active cars found.</p>
                    @endif
                </div>
            </div>

            <div class="bg-gray-300 shadow-md rounded-lg mb-6">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4">Deactivated Cars</h3>
                    <div class="space-y-4">
                        @foreach($deactivatedCars as $car)
                            <div class="bg-white border border-black rounded-lg  pb-2 flex items-center">
                                <div class="w-1/2">
                                    <h4 class="font-bold">{{ $car->title }}</h4>
                                    <p>Make: {{ $car->make }}</p>
                                    <p>Model: {{ $car->model }}</p>
                                    <p>Price: ${{ number_format($car->price, 2) }}</p>
                                    <p>Status: 
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                            Deactivated
                                        </span>
                                    </p>
                                    <div class="mt-2 flex space-x-2">
                                        <button onclick="showCarDetails({{ $car->id }})" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md text-sm">
                                            View Details
                                        </button>
                                        <form action="{{ route('admin.cars.toggle-status', $car->id) }}" method="POST" class="inline">
                                            @csrf
                                            @method('PUT')
                                            <button type="submit" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-md text-sm">
                                                Activate
                                            </button>
                                        </form>
                                        <form action="{{ route('admin.cars.delete', $car->id) }}" method="POST" class="inline"
                                            onsubmit="return confirm('Are you sure you want to permanently delete this car? This action cannot be undone.');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md text-sm">
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                <div class="w-1/2">
                                    <img src="{{ $car->photos->first() ? Storage::url($car->photos->first()->path) : asset('images/no-image.png') }}" 
                                         alt="{{ $car->title }}" 
                                         class="w-full h-48 object-cover rounded-lg">
                                </div>
                            </div>
                        @endforeach
                    </div>
                    @if($deactivatedCars->isEmpty())
                        <p class="text-gray-600">No deactivated cars found.</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

@include('admin.cars.partials.car-details-modal')
