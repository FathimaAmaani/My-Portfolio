<div id="carDetailsModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Car Details</h3>
            <div id="carDetailsContent" class="space-y-3">
                <!-- Image Gallery -->
                <div id="carImages" class="mb-4">
                    <!-- Images will be loaded here -->
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <p><span class="font-semibold">Make:</span> <span id="carMake"></span></p>
                    <p><span class="font-semibold">Model:</span> <span id="carModel"></span></p>
                    <p><span class="font-semibold">Year:</span> <span id="carYear"></span></p>
                    <p><span class="font-semibold">Price:</span> $<span id="carPrice"></span></p>
                    <p><span class="font-semibold">Body Type:</span> <span id="carBodyType"></span></p>
                    <p><span class="font-semibold">Transmission:</span> <span id="carTransmission"></span></p>
                    <p><span class="font-semibold">Fuel Type:</span> <span id="carFuelType"></span></p>
                    <p><span class="font-semibold">Mileage:</span> <span id="carMileage"></span></p>
                </div>
                <div>
                    <p class="font-semibold">Description:</p>
                    <p id="carDescription" class="text-gray-600"></p>
                </div>
            </div>
        </div>
        <div class="mt-4 flex justify-end">
            <button onclick="closeCarDetails()" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md text-sm">
                Close
            </button>
        </div>
    </div>
</div>

<script>
function showCarDetails(carId) {
    fetch(`/admin/cars/${carId}/details`)
        .then(response => response.json())
        .then(car => {
            // Load images
            const imagesContainer = document.getElementById('carImages');
            imagesContainer.innerHTML = ''; // Clear existing images
            
            if (car.photos && car.photos.length > 0) {
                const imageGrid = document.createElement('div');
                imageGrid.className = 'grid grid-cols-1 md:grid-cols-2 gap-4';
                
                car.photos.forEach(photo => {
                    const img = document.createElement('img');
                    img.src = `/storage/${photo.path}`;
                    img.alt = `${car.make} ${car.model}`;
                    img.className = 'w-full h-48 object-cover rounded-lg';
                    imageGrid.appendChild(img);
                });
                
                imagesContainer.appendChild(imageGrid);
            } else {
                imagesContainer.innerHTML = '<p class="text-gray-500">No images available</p>';
            }

            // Load other details
            document.getElementById('carMake').textContent = car.make;
            document.getElementById('carModel').textContent = car.model;
            document.getElementById('carYear').textContent = car.year;
            document.getElementById('carPrice').textContent = new Intl.NumberFormat().format(car.price);
            document.getElementById('carBodyType').textContent = car.body_type;
            document.getElementById('carTransmission').textContent = car.transmission;
            document.getElementById('carFuelType').textContent = car.fuel_type;
            document.getElementById('carMileage').textContent = car.mileage;
            document.getElementById('carDescription').textContent = car.description;
            
            document.getElementById('carDetailsModal').classList.remove('hidden');
        });
}

function closeCarDetails() {
    document.getElementById('carDetailsModal').classList.add('hidden');
}
</script> 