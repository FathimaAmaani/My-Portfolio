<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Active Cars') }}
            </h2>
            <a href="{{ route('admin.dashboard') }}" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md text-sm">
                Back to Dashboard
            </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            @if(session('success'))
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
                    {{ session('success') }}
                </div>
            @endif

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                @forelse($cars as $car)
                    <div class="bg-white rounded-lg shadow-md overflow-hidden">
                        @if($car->photos->isNotEmpty())
                            <img src="{{ Storage::url($car->photos->first()->path) }}" 
                                 alt="{{ $car->make }} {{ $car->model }}" 
                                 class="w-full h-48 object-cover">
                        @else
                            <div class="w-full h-48 bg-gray-200 flex items-center justify-center">
                                <span class="text-gray-500">No image available</span>
                            </div>
                        @endif
                        <div class="p-4">
                            <h3 class="text-lg font-semibold text-gray-800">{{ $car->make }} {{ $car->model }}</h3>
                            <p class="text-gray-600">Year: {{ $car->year }}</p>
                            <p class="text-gray-600">Price: ${{ number_format($car->price, 2) }}</p>
                            <div class="mt-4 flex space-x-2">
                                <button onclick="showCarDetails({{ $car->id }})" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md text-sm">
                                    View Details
                                </button>
                                <form action="{{ route('admin.cars.toggle-status', $car->id) }}" method="POST" class="inline">
                                    @csrf
                                    @method('PUT')
                                    <button type="submit" class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-md text-sm">
                                        Deactivate
                                    </button>
                                </form>
                                <form action="{{ route('admin.cars.delete', $car->id) }}" method="POST" class="inline"
                                    onsubmit="return confirm('Are you sure you want to permanently delete this car? This action cannot be undone.');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md text-sm">
                                        Delete
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="col-span-3 bg-white rounded-lg shadow-md p-6 text-center">
                        <p class="text-gray-500">No active cars found.</p>
                    </div>
                @endforelse
            </div>
        </div>
    </div>

    @include('admin.cars.partials.car-details-modal')
</x-app-layout> 