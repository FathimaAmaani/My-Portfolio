<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Bids Management') }}
            </h2>
            <a href="{{ route('dashboard') }}" 
               class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                Back to Dashboard
            </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Received Bids -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="text-lg font-semibold mb-4">Received Bids</h3>
                    
                    @if($receivedBids->isEmpty())
                        <p class="text-gray-500">No bids received for your cars.</p>
                    @else
                        <div class="grid grid-cols-1 gap-4">
                            @foreach($receivedBids as $bid)
                                <div class="border rounded-lg p-4 {{ $bid->status === 'pending' ? 'bg-yellow-50' : ($bid->status === 'accepted' ? 'bg-green-50' : 'bg-gray-50') }}">
                                    <div class="flex justify-between">
                                        <div class="flex-1">
                                            <h4 class="font-semibold">{{ $bid->car->title }}</h4>
                                            <div class="mt-2 space-y-1">
                                                <p><span class="font-medium">Bidder:</span> {{ $bid->user->name }}</p>
                                                <p><span class="font-medium">Contact:</span> {{ $bid->user->phone_number }}</p>
                                                <p><span class="font-medium">Location:</span> {{ $bid->user->address }}</p>
                                                <p><span class="font-medium">Bid Amount:</span> ${{ number_format($bid->amount, 2) }}</p>
                                                @if($bid->message)
                                                    <p><span class="font-medium">Message:</span> {{ $bid->message }}</p>
                                                @endif
                                                <p><span class="font-medium">Status:</span> 
                                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                                        {{ $bid->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                                           ($bid->status === 'accepted' ? 'bg-green-100 text-green-800' : 
                                                           'bg-red-100 text-red-800') }}">
                                                        {{ ucfirst($bid->status) }}
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                        
                                        @if($bid->status !== 'rejected')
                                            <div class="flex flex-col space-y-2">
                                                @if($bid->status === 'pending')
                                                    <div class="flex space-x-2">
                                                        <form action="{{ route('bids.update.status', $bid->id) }}" method="POST">
                                                            @csrf
                                                            @method('PATCH')
                                                            <button type="submit" name="status" value="accepted" 
                                                                    class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                                                Accept Bid
                                                            </button>
                                                        </form>

                                                        <form action="{{ route('bids.update.status', $bid->id) }}" method="POST">
                                                            @csrf
                                                            @method('PATCH')
                                                            <button type="submit" name="status" value="rejected" 
                                                                    class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                                                Reject Bid
                                                            </button>
                                                        </form>
                                                    </div>
                                                @endif

                                                @if($bid->status === 'accepted')
                                                    <div class="text-sm text-gray-600">
                                                        <p class="font-medium">Contact Details:</p>
                                                        <p>Phone: {{ $bid->user->phone_number ?? 'Not provided' }}</p>
                                                        <p>Location: {{ $bid->user->address ?? 'Not provided' }}</p>
                                                    </div>
                                                @endif
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>

            <!-- My Bids -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="text-lg font-semibold mb-4">My Bids</h3>
                    
                    @if($userBids->isEmpty())
                        <p class="text-gray-500">You haven't placed any bids yet.</p>
                    @else
                        <div class="grid grid-cols-1 gap-4">
                            @foreach($userBids as $bid)
                                <div class="border rounded-lg p-4 {{ $bid->status === 'pending' ? 'bg-yellow-50' : ($bid->status === 'accepted' ? 'bg-green-50' : 'bg-gray-50') }}">
                                    <h4 class="font-semibold">{{ $bid->car->title }}</h4>
                                    <div class="mt-2 space-y-1">
                                        <p><span class="font-medium">Owner:</span> {{ $bid->car->user->name }}</p>
                                        <p><span class="font-medium">Bid Amount:</span> ${{ number_format($bid->amount, 2) }}</p>
                                        <p><span class="font-medium">Status:</span> 
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                                {{ $bid->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                                   ($bid->status === 'accepted' ? 'bg-green-100 text-green-800' : 
                                                   'bg-red-100 text-red-800') }}">
                                                {{ ucfirst($bid->status) }}
                                            </span>
                                        </p>
                                        @if($bid->message)
                                            <p><span class="font-medium">Message:</span> {{ $bid->message }}</p>
                                        @endif

                                        <!-- Show owner's contact details when accepted -->
                                        @if($bid->status === 'accepted')
                                            <div class="mt-4 p-3 bg-green-50 rounded-md">
                                                <p class="font-medium text-green-800">Owner's Contact Details:</p>
                                                <p class="text-green-700">Phone: {{ $bid->car->user->phone_number ?? 'Not provided' }}</p>
                                                <p class="text-green-700">Location: {{ $bid->car->user->address ?? 'Not provided' }}</p>
                                            </div>
                                        @endif

                                        <!-- Add this edit button for pending bids -->
                                        @if($bid->status === 'pending')
                                            <div class="mt-4">
                                                <a href="{{ route('bids.edit', $bid) }}" 
                                                   class="inline-flex items-center px-4 py-2 bg-blue-500 hover:bg-blue-700 text-white font-bold rounded">
                                                    Edit Bid
                                                </a>
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 