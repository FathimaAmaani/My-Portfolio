<section>
    <header class="text-center mb-6">
        <h2 class="text-lg font-medium text-gray-900">
            {{ __('Profile Information') }}
        </h2>
        <p class="mt-1 text-sm text-gray-600">
            {{ __("Update your account's profile information and email address.") }}
        </p>
    </header>

    <!-- Profile Picture Preview -->
    <div class="flex justify-center mb-4">
        <div id="image-preview" class="w-32 h-32 rounded-full overflow-hidden border-2 border-gray-300 flex items-center justify-center">
            <img id="preview-image" src="{{ $user->profile_picture ? asset('storage/' . $user->profile_picture) : '#' }}" alt="Profile Picture" class="{{ $user->profile_picture ? '' : 'hidden' }} w-full h-full object-cover" />
        </div>
    </div>

    <form method="post" action="{{ route('profile.update') }}" class="mt-6 space-y-6" enctype="multipart/form-data">
        @csrf
        @method('patch')

        <!-- Name -->
        <div>
            <x-input-label for="name" :value="__('Name')" />
            <x-text-input id="name" name="name" type="text" class="block mt-1 w-full" :value="old('name', $user->name)" required autofocus />
            <x-input-error :messages="$errors->get('name')" class="mt-2" />
        </div>

        <!-- Email Address -->
        <div class="mt-4">
            <x-input-label for="email" :value="__('Email')" />
            <x-text-input id="email" name="email" type="email" class="block mt-1 w-full" :value="old('email', $user->email)" required />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>

        <!-- Address -->
        <div class="mt-4">
            <x-input-label for="address" :value="__('Address')" />
            <textarea id="address" name="address" class="block mt-1 w-full" required>{{ old('address', $user->address) }}</textarea>
            <x-input-error :messages="$errors->get('address')" class="mt-2" />
        </div>

        <!-- Gender -->
        <div class="mt-4">
            <x-input-label for="gender" :value="__('Gender')" />
            <select id="gender" name="gender" class="block mt-1 w-full" required>
                <option value="Male" {{ old('gender', $user->gender) == 'Male' ? 'selected' : '' }}>Male</option>
                <option value="Female" {{ old('gender', $user->gender) == 'Female' ? 'selected' : '' }}>Female</option>
            </select>
            <x-input-error :messages="$errors->get('gender')" class="mt-2" />
        </div>

        <!-- Phone Number -->
        <div class="mt-4">
            <x-input-label for="phone_number" :value="__('Phone Number')" />
            <x-text-input id="phone_number" name="phone_number" type="text" class="block mt-1 w-full" :value="old('phone_number', $user->phone_number)" required />
            <x-input-error :messages="$errors->get('phone_number')" class="mt-2" />
        </div>

        <!-- Profile Picture Upload -->
        <div class="mt-4">
            <x-input-label for="profile_picture" :value="__('Profile Picture')" />
            <x-text-input id="profile_picture" class="block mt-1 w-full" type="file" name="profile_picture" accept="image/*" onchange="previewImage(event)" />
            <x-input-error :messages="$errors->get('profile_picture')" class="mt-2" />
        </div>

        <div class="flex items-center justify-end mt-4">
            <x-primary-button>
                {{ __('Save') }}
            </x-primary-button>
        </div>
    </form>

    @if ($user->profile_picture)
        <form method="post" action="{{ route('profile.picture.delete') }}" class="mt-2">
            @csrf
            @method('delete')
            <x-danger-button>
                {{ __('Delete Profile Picture') }}
            </x-danger-button>
        </form>
    @endif

    <script>
        function previewImage(event) {
            const preview = document.getElementById('preview-image');
            const imagePreviewContainer = document.getElementById('image-preview');
            const file = event.target.files[0];

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.classList.remove('hidden');
                }
                reader.readAsDataURL(file);
                imagePreviewContainer.classList.remove('border-gray-300');
                imagePreviewContainer.classList.add('border-blue-500');
            } else {
                preview.classList.add('hidden');
                imagePreviewContainer.classList.add('border-gray-300');
            }
        }
    </script>
</section>
