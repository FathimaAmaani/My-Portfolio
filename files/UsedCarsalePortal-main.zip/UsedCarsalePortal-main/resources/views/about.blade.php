<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('About Us') }}
        </h2>
    </x-slot>

    <div class="bg-gray-100 py-10">
        <div class="container mx-auto px-4">
            <!-- About Us Heading -->
            <div class="text-center mb-10">
                <h1 class="text-4xl font-bold text-gray-800">About Us</h1>
                <p class="text-gray-600 mt-4 text-lg">Discover who we are and what drives us forward.</p>
            </div>
    
            <!-- Introduction Section -->
            <div class="mb-12 bg-white shadow-lg rounded-lg p-6 flex items-center">
                <img src="{{ asset('images/about-us.jpg') }}" alt="About Us" class="w-1/3 rounded-md mr-6 shadow-xl shadow-black">
                <div>
                    <h2 class="text-2xl font-semibold text-gray-700 mb-4">Who We Are</h2>
                    <p class="text-gray-600 leading-relaxed">
                        At ABC.Cars, we are passionate about connecting car enthusiasts with their dream vehicles. With years of expertise
                        in the automotive industry, we strive to provide exceptional services that make buying and selling vehicles
                        seamless and enjoyable for everyone.
                    </p>
                </div>
            </div>
    
            <!-- Mission and Vision Section -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                <!-- Mission -->
                <div class="bg-white shadow-lg rounded-lg p-6">
                    <h2 class="text-2xl font-semibold text-gray-700 mb-4">Our Mission</h2>
                    <p class="text-gray-600 leading-relaxed">
                        To revolutionize the automotive marketplace with innovative solutions and exceptional customer experiences.
                    </p>
                </div>
                <!-- Vision -->
                <div class="bg-white shadow-lg rounded-lg p-6">
                    <h2 class="text-2xl font-semibold text-gray-700 mb-4">Our Vision</h2>
                    <p class="text-gray-600 leading-relaxed">
                        To be the most trusted platform for buying and selling vehicles, empowering individuals with ease and transparency.
                    </p>
                </div>
            </div>
    
            <!-- Team or Services Overview -->
            <div class="bg-white shadow-lg rounded-lg p-6">
                <h2 class="text-2xl font-semibold text-gray-700 mb-4">What We Offer</h2>
                <ul class="list-disc list-inside text-gray-600 leading-relaxed">
                    <li>Comprehensive car listings with detailed information.</li>
                    <li>Reliable customer support to assist with every step of the process.</li>
                    <li>Secure and trusted payment and transaction services.</li>
                    <li>Expert advice for buyers and sellers to make informed decisions.</li>
                </ul>
            </div>
    
            <!-- Call to Action -->
            <div class="text-center mt-10">
                <h3 class="text-xl font-semibold text-gray-700">Ready to Start Your Journey?</h3>
                <a href="{{ route('contact') }}" class="mt-4 inline-block bg-blue-500 text-white py-2 px-4 rounded-lg shadow-md hover:bg-blue-600">
                    Contact Us Today
                </a>
            </div>
        </div>
    </div>
</x-app-layout>