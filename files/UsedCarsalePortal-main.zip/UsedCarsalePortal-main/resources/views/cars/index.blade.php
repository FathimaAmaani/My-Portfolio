@extends('layouts.app')

@section('content')
<h1 class="text-2xl font-bold mb-4">Car Listings</h1>

<div class="container mx-auto px-4 py-8">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @foreach($cars as $car)
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <!-- Car Image -->
                @if($car->photos->count() > 0)
                    <div class="h-48 overflow-hidden">
                        <img src="{{ Storage::url($car->photos->first()->path) }}" 
                             alt="{{ $car->title }}" 
                             class="w-full h-full object-cover">
                    </div>
                @else
                    <div class="h-48 bg-gray-200 flex items-center justify-center">
                        <span class="text-gray-400">No Image Available</span>
                    </div>
                @endif

                <!-- Car Details -->
                <div class="p-4">
                    <h3 class="text-xl font-semibold mb-2">{{ $car->title }}</h3>
                    <div class="space-y-2">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Make:</span>
                            <span class="font-medium">{{ $car->make }}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Model:</span>
                            <span class="font-medium">{{ $car->model }}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Year:</span>
                            <span class="font-medium">{{ $car->registration_year }}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Price:</span>
                            <span class="font-medium">${{ number_format($car->price, 2) }}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Mileage:</span>
                            <span class="font-medium">{{ number_format($car->mileage) }} km</span>
                        </div>
                    </div>

                    <!-- View Details Button -->
                    <div class="mt-4">
                        <a href="{{ route('cars.show', $car) }}" 
                           class="block w-full text-center bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">
                            View Details
                        </a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>

    @if($cars->isEmpty())
        <div class="text-center py-8">
            <p class="text-gray-500">No cars available at the moment.</p>
        </div>
    @endif
</div>
@endsection
