<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Available Cars') }}
            </h2>
            <a href="{{ route('dashboard') }}" 
               class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                Back to Dashboard
            </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Filter Section -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6">
                    <form id="filterForm" method="GET" class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label for="make" class="block text-sm font-medium text-gray-700">Make</label>
                                <select id="make" name="make" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                    <option value="">All Makes</option>
                                    @foreach($makes as $make)
                                        <option value="{{ $make }}" {{ request('make') == $make ? 'selected' : '' }}>
                                            {{ $make }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div>
                                <label for="price_range" class="block text-sm font-medium text-gray-700">Price Range</label>
                                <select id="price_range" name="price_range" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                    <option value="">Any Price</option>
                                    <option value="0-5000" {{ request('price_range') == '0-5000' ? 'selected' : '' }}>Under $5,000</option>
                                    <option value="5000-10000" {{ request('price_range') == '5000-10000' ? 'selected' : '' }}>$5,000 - $10,000</option>
                                    <option value="10000-20000" {{ request('price_range') == '10000-20000' ? 'selected' : '' }}>$10,000 - $20,000</option>
                                    <option value="20000-30000" {{ request('price_range') == '20000-30000' ? 'selected' : '' }}>$20,000 - $30,000</option>
                                    <option value="30000-50000" {{ request('price_range') == '30000-50000' ? 'selected' : '' }}>$30,000 - $50,000</option>
                                    <option value="50000+" {{ request('price_range') == '50000+' ? 'selected' : '' }}>Over $50,000</option>
                                </select>
                            </div>

                            <div>
                                <label for="registration_year" class="block text-sm font-medium text-gray-700">Registration Year</label>
                                <select id="registration_year" name="registration_year" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                    <option value="">Any Year</option>
                                    @foreach($years as $year)
                                        <option value="{{ $year }}" {{ request('registration_year') == $year ? 'selected' : '' }}>
                                            {{ $year }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="flex justify-end">
                            <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                                Apply Filters
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Cars Grid -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    @if($cars->isEmpty())
                        <p class="text-center text-gray-500">No cars are currently available.</p>
                    @else
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            @foreach($cars as $car)
                                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                                    <!-- Car Image -->
                                    <div class="h-48 overflow-hidden">
                                        @if($car->photos->count() > 0)
                                            <img src="{{ Storage::url($car->photos->first()->path) }}" 
                                                 alt="{{ $car->title }}" 
                                                 class="w-full h-48 object-cover">
                                        @else
                                            <div class="w-full h-48 bg-gray-200 flex items-center justify-center">
                                                <span class="text-gray-400">No Image</span>
                                            </div>
                                        @endif
                                    </div>

                                    <!-- Car Details -->
                                    <div class="p-4">
                                        <h4 class="text-xl font-semibold mb-2">{{ $car->title }}</h4>
                                        
                                        <div class="space-y-2">
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Make:</span>
                                                <span class="font-medium">{{ $car->make }}</span>
                                            </div>
                                            
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Price:</span>
                                                <span class="font-medium">${{ number_format($car->price, 2) }}</span>
                                            </div>
                                        </div>

                                        <!-- View Details Button -->
                                        <div class="mt-4">
                                            <a href="{{ route('cars.show', $car->id) }}" 
                                               class="block w-full text-center bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                                                View Details
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                        <!-- Pagination -->
                        <div class="mt-6">
                            {{ $cars->links() }}
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 