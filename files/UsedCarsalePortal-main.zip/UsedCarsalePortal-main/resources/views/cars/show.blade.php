<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Car Details') }}
            </h2>
            <div class="space-x-4">
                @auth
                    @if(auth()->id() !== $car->user_id)
                        <a href="{{ route('test-drives.create', ['car' => $car->id]) }}" 
                           class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                            Schedule Test Drive
                        </a>
                        <a href="{{ route('bids.create', ['car' => $car->id]) }}" 
                           class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            Submit Bid
                        </a>
                    @endif
                @endauth
                <a href="{{ url()->previous() }}" 
                   class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                    Back
                </a>
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <!-- Car Images Carousel -->
                    <div class="mb-8">
                        @if($car->photos->count() > 0)
                            <div class="relative h-96">
                                @foreach($car->photos as $photo)
                                    <img src="{{ Storage::url($photo->path) }}" 
                                         alt="{{ $car->title }}"
                                         class="absolute inset-0 w-full h-full object-cover">
                                @endforeach
                            </div>
                        @else
                            <div class="h-96 bg-gray-200 flex items-center justify-center">
                                <span class="text-gray-400 text-lg">No Images Available</span>
                            </div>
                        @endif
                    </div>

                    <!-- Car Details -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <h3 class="text-2xl font-bold mb-4">{{ $car->title }}</h3>
                            
                            <div class="space-y-4">
                                <div>
                                    <p class="text-gray-600">Make</p>
                                    <p class="font-semibold">{{ $car->make }}</p>
                                </div>
                                
                                <div>
                                    <p class="text-gray-600">Model</p>
                                    <p class="font-semibold">{{ $car->model }}</p>
                                </div>
                                
                                <div>
                                    <p class="text-gray-600">Year</p>
                                    <p class="font-semibold">{{ $car->year }}</p>
                                </div>
                                
                                <div>
                                    <p class="text-gray-600">Price</p>
                                    <p class="font-semibold text-xl text-green-600">${{ number_format($car->price, 2) }}</p>
                                </div>
                            </div>
                        </div>

                        <div>
                            <h4 class="text-xl font-semibold mb-4">Additional Information</h4>
                            
                            <div class="space-y-4">
                                <div>
                                    <p class="text-gray-600">Mileage</p>
                                    <p class="font-semibold">{{ number_format($car->mileage) }} km</p>
                                </div>
                                
                                <div>
                                    <p class="text-gray-600">Transmission</p>
                                    <p class="font-semibold">{{ $car->transmission }}</p>
                                </div>
                                
                                <div>
                                    <p class="text-gray-600">Fuel Type</p>
                                    <p class="font-semibold">{{ $car->fuel_type }}</p>
                                </div>
                                
                                <div>
                                    <p class="text-gray-600">Status</p>
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                        {{ $car->status === 'active' ? 'bg-green-100 text-green-800' : 
                                           ($car->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800') }}">
                                        {{ ucfirst($car->status) }}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Description -->
                    <div class="mt-8">
                        <h4 class="text-xl font-semibold mb-4">Description</h4>
                        <p class="text-gray-700 whitespace-pre-line">{{ $car->description }}</p>
                    </div>

                    <!-- Seller Information -->
                    <div class="mt-8 p-4 bg-gray-50 rounded-lg">
                        <h4 class="text-xl font-semibold mb-4">Seller Information</h4>
                        @auth
                            <div class="space-y-2">
                                <p><span class="font-medium">Name:</span> {{ $car->user->name }}</p>
                                @if(auth()->id() === $car->user_id || 
                                   (isset($hasApprovedBid) && $hasApprovedBid) || 
                                   (isset($hasApprovedTestDrive) && $hasApprovedTestDrive))
                                    <p><span class="font-medium">Contact:</span> {{ $car->user->phone_number ?? 'Not provided' }}</p>
                                    <p><span class="font-medium">Location:</span> {{ $car->user->address ?? 'Not provided' }}</p>
                                @else
                                    <p class="text-gray-600 italic">Contact information will be visible after your bid or test drive request is approved</p>
                                @endif
                            </div>
                        @else
                            <div class="text-gray-600">
                                <p class="italic">Please <a href="{{ route('login') }}" class="text-blue-600 hover:underline">login</a> or 
                                <a href="{{ route('register') }}" class="text-blue-600 hover:underline">register</a> to view seller information</p>
                            </div>
                        @endauth
                    </div>

                    @auth
                        @if(auth()->id() !== $car->user_id)
                            <div class="mt-8 flex space-x-4">
                                <a href="{{ route('test-drives.create', ['car' => $car->id]) }}" 
                                   class="flex-1 bg-green-500 hover:bg-green-700 text-white font-bold py-3 px-4 rounded text-center">
                                    Schedule Test Drive
                                </a>
                                <a href="{{ route('bids.create', ['car' => $car->id]) }}" 
                                   class="flex-1 bg-blue-500 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded text-center">
                                    Submit Bid
                                </a>
                            </div>
                        @endif
                    @endauth
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
