<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Deactivated Listings') }}
            </h2>
            <a href="{{ route('dashboard') }}" 
               class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                Back to Dashboard
            </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            @if(session('success'))
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline">{{ session('success') }}</span>
                </div>
            @endif

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    @if($cars->isEmpty())
                        <p class="text-gray-500 text-center py-4">No deactivated listings found.</p>
                    @else
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            @foreach($cars as $car)
                                <div class="border rounded-lg p-4 relative">
                                    @if($car->photos->first())
                                        <img src="{{ Storage::url($car->photos->first()->path) }}" 
                                             alt="{{ $car->title }}" 
                                             class="w-full h-48 object-cover rounded-lg mb-4">
                                    @endif
                                    
                                    <h3 class="text-lg font-semibold mb-2">{{ $car->title }}</h3>
                                    <p class="text-gray-600 mb-2">${{ number_format($car->price, 2) }}</p>
                                    
                                    <div class="flex space-x-2 mt-4">
                                        <form action="{{ route('cars.toggle-status', $car) }}" method="POST" class="inline">
                                            @csrf
                                            @method('PUT')
                                            <button type="submit" 
                                                    class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                                Reactivate
                                            </button>
                                        </form>
                                        
                                        <form action="{{ route('cars.destroy', $car) }}" method="POST" class="inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" 
                                                    class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
                                                    onclick="return confirm('Are you sure you want to permanently delete this listing?')">
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        
                        <div class="mt-6">
                            {{ $cars->links() }}
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 