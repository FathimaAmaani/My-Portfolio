<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Test Drives Management') }}
            </h2>
            <a href="{{ route('dashboard') }}" 
               class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                Back to Dashboard
            </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Received Test Drive Requests -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="text-lg font-semibold mb-4">Received Test Drive Requests</h3>
                    
                    @if($receivedTestDrives->isEmpty())
                        <p class="text-gray-500">No test drive requests received for your cars.</p>
                    @else
                        <div class="grid grid-cols-1 gap-4">
                            @foreach($receivedTestDrives as $testDrive)
                                <div class="border rounded-lg p-4 {{ $testDrive->status === 'pending' ? 'bg-yellow-50' : ($testDrive->status === 'approved' ? 'bg-green-50' : 'bg-gray-50') }}">
                                    <div class="flex justify-between">
                                        <div class="flex-1">
                                            <h4 class="font-semibold">{{ $testDrive->car->title }}</h4>
                                            <div class="mt-2 space-y-1">
                                                <p><span class="font-medium">Requested by:</span> {{ $testDrive->user->name }}</p>
                                                <p><span class="font-medium">Contact:</span> {{ $testDrive->user->phone_number }}</p>
                                                <p><span class="font-medium">Location:</span> {{ $testDrive->user->address }}</p>
                                                <p><span class="font-medium">Scheduled for:</span> {{ $testDrive->scheduled_at->format('F j, Y g:i A') }}</p>
                                                @if($testDrive->notes)
                                                    <p><span class="font-medium">Notes:</span> {{ $testDrive->notes }}</p>
                                                @endif
                                                <p><span class="font-medium">Status:</span> 
                                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                                        {{ $testDrive->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                                           ($testDrive->status === 'approved' ? 'bg-green-100 text-green-800' : 
                                                           'bg-red-100 text-red-800') }}">
                                                        {{ ucfirst($testDrive->status) }}
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                        
                                        @if($testDrive->status === 'pending')
                                            <div class="flex space-x-2">
                                                <form action="{{ route('test-drives.update.status', $testDrive->id) }}" method="POST">
                                                    @csrf
                                                    @method('PATCH')
                                                    <button type="submit" name="status" value="approved" 
                                                            class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                                        Approve Test Drive
                                                    </button>
                                                </form>

                                                <form action="{{ route('test-drives.update.status', $testDrive->id) }}" method="POST">
                                                    @csrf
                                                    @method('PATCH')
                                                    <button type="submit" name="status" value="rejected" 
                                                            class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                                        Reject Test Drive
                                                    </button>
                                                </form>
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>

            <!-- My Test Drive Requests -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="text-lg font-semibold mb-4">My Test Drive Requests</h3>
                    
                    @if($userTestDrives->isEmpty())
                        <p class="text-gray-500">You haven't requested any test drives yet.</p>
                    @else
                        <div class="grid grid-cols-1 gap-4">
                            @foreach($userTestDrives as $testDrive)
                                <div class="border rounded-lg p-4 {{ $testDrive->status === 'pending' ? 'bg-yellow-50' : ($testDrive->status === 'approved' ? 'bg-green-50' : 'bg-gray-50') }}">
                                    <h4 class="font-semibold">{{ $testDrive->car->title }}</h4>
                                    <div class="mt-2 space-y-1">
                                        <p><span class="font-medium">Owner:</span> {{ $testDrive->car->user->name }}</p>
                                        <p><span class="font-medium">Scheduled for:</span> {{ $testDrive->scheduled_at->format('F j, Y g:i A') }}</p>
                                        <p><span class="font-medium">Status:</span> 
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                                {{ $testDrive->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                                   ($testDrive->status === 'approved' ? 'bg-green-100 text-green-800' : 
                                                   'bg-red-100 text-red-800') }}">
                                                {{ ucfirst($testDrive->status) }}
                                            </span>
                                        </p>
                                        @if($testDrive->notes)
                                            <p><span class="font-medium">Notes:</span> {{ $testDrive->notes }}</p>
                                        @endif

                                        <!-- Show owner's contact details when approved -->
                                        @if($testDrive->status === 'approved')
                                            <div class="mt-4 p-3 bg-green-50 rounded-md">
                                                <p class="font-medium text-green-800">Owner's Contact Details:</p>
                                                <p class="text-green-700">Phone: {{ $testDrive->car->user->phone_number ?? 'Not provided' }}</p>
                                                <p class="text-green-700">Location: {{ $testDrive->car->user->address ?? 'Not provided' }}</p>
                                            </div>
                                        @endif

                                        <!-- Add this edit button for pending test drives -->
                                        @if($testDrive->status === 'pending')
                                            <div class="mt-4">
                                                <a href="{{ route('test-drives.edit', $testDrive) }}" 
                                                   class="inline-flex items-center px-4 py-2 bg-blue-500 hover:bg-blue-700 text-white font-bold rounded">
                                                    Edit Test Drive
                                                </a>
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 