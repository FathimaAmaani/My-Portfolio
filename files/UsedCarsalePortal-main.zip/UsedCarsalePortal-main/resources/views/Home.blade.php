<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ config('app.name') }} - Home</title>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="font-oswald antialiased">
    <!-- Header Section -->
    <header class="bg-white shadow fixed w-full top-0 z-50">
        <nav class="container mx-auto px-6 py-3">
            <div class="flex justify-between items-center">
                <div class="flex items-center">
                    <a href="/" class="flex items-center">
                        <img src="{{ asset('images/download.png') }}" class="w-20 h-20" alt="Logo"/>
                        <span class="ml-3 text-xl font-weigh: bold">ABC Cars Portal</span>
                    </a>
                </div>
                <div class="hidden md:flex items-center space-x-8">
                    <a href="/" class="text-gray-600 hover:text-gray-900">Home</a>
                    <a href="{{route('about')}}" class="text-gray-600 hover:text-gray-900">About Us</a>
                    <a href="{{route('contact')}}" class="text-gray-600 hover:text-gray-900">Contact Us</a>
                    @auth
                        <a href="{{ route('dashboard') }}" class="text-gray-600 hover:text-gray-900">{{ Auth::user()->name }}</a>
                        <form action="{{ route('logout') }}" method="POST" class="inline-block">
                            @csrf
                            <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">Logout</button>
                        </form>
                    @else
                        <a href="{{ route('login') }}" class="text-gray-600 hover:text-gray-900">Login</a>
                        <a href="{{ route('register') }}" class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">Register</a>
                    @endauth
                </div>
            </div>
        </nav>
    </header>

    <!-- Hero Section with Background Image -->
    <div class="relative w-full h-[70vh] bg-cover bg-center" style="background-image: url('{{ asset('images/background.jpeg') }}');">
        <div class="absolute top-0 w-full text-center text-black z-40" style="padding-top: 21%; color: #FFFFA7; font-size: 64px; font-weight: bold; text-shadow: 5px 5px 5px #333333;">
            <h1 style="text-align: left; margin-left:20px">Find Your Dream Car Here</h1>
        </div>
    </div>

    <!-- Main Content -->
    <main class="container mx-auto px-4 py-10 bg-gray-700 bg-opacity-90 rounded-lg shadow-lg mt-10">
        <h1 class="text-3xl font-bold text-center mb-8 text-white">Available Cars</h1><br>

        <!-- Filter Section -->
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
            <div class="p-6">
                <form id="filterForm" method="GET" class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="make" class="block text-sm font-medium text-gray-700">Make</label>
                            <select id="make" name="make" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                <option value="">Select Make</option>
                                @foreach($makes as $make)
                                    <option value="{{ $make }}" {{ request('make') == $make ? 'selected' : '' }}>
                                        {{ $make }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div>
                            <label for="price_range" class="block text-sm font-medium text-gray-700">Price Range</label>
                            <select id="price_range" name="price_range" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                <option value="">Any Price</option>
                                <option value="0-5000" {{ request('price_range') == '0-5000' ? 'selected' : '' }}>Under $5,000</option>
                                <option value="5000-10000" {{ request('price_range') == '5000-10000' ? 'selected' : '' }}>$5,000 - $10,000</option>
                                <option value="10000-20000" {{ request('price_range') == '10000-20000' ? 'selected' : '' }}>$10,000 - $20,000</option>
                                <option value="20000-30000" {{ request('price_range') == '20000-30000' ? 'selected' : '' }}>$20,000 - $30,000</option>
                                <option value="30000-50000" {{ request('price_range') == '30000-50000' ? 'selected' : '' }}>$30,000 - $50,000</option>
                                <option value="50000+" {{ request('price_range') == '50000+' ? 'selected' : '' }}>Over $50,000</option>
                            </select>
                        </div>

                        <div>
                            <label for="registration_year" class="block text-sm font-medium text-gray-700">Registration Year</label>
                            <select id="registration_year" name="registration_year" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                <option value="">Any Year</option>
                                @foreach($years as $year)
                                    <option value="{{ $year }}" {{ request('registration_year') == $year ? 'selected' : '' }}>
                                        {{ $year }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="flex justify-end">
                        <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                            Apply Filters
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Cars Grid -->
        <div class="bg-gray-300 overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6">
                @if($cars->isEmpty())
                    <p class="text-center text-gray-500">No cars are currently available.</p>
                @else
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        @foreach($cars as $car)
                            <div class="bg-white rounded-lg shadow-md p-6">
                                @if($car->photos->count() > 0)
                                    <img src="{{ asset('storage/' . $car->photos->first()->path) }}" 
                                         alt="{{ $car->title }}" 
                                         class="w-full h-48 object-cover rounded-lg mb-4">
                                @endif
                                
                                <h2 class="text-xl font-bold mb-2">{{ $car->title }}</h2>
                                <p class="text-gray-600 mb-2">${{ number_format($car->price, 2) }}</p>
                                <p class="text-gray-500 mb-4">{{ Str::limit($car->description, 100) }}</p>
                                
                                <a href="{{ route('cars.show', ['car' => $car->id]) }}" 
                                   class="inline-block px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                                    View Details
                                </a>
                            </div>
                        @endforeach
                    </div>

                    <!-- Pagination -->
                    <div class="mt-6">
                        {{ $cars->links() }}
                    </div>
                @endif
            </div>
        </div>
    </main>

    @push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get form elements
            const filterForm = document.getElementById('filterForm');
            const makeSelect = document.getElementById('make');
            const priceRangeSelect = document.getElementById('price_range');
            const registrationYearSelect = document.getElementById('registration_year');

            // Handle form submission
            filterForm.addEventListener('submit', function(e) {
                // Remove empty values before submitting
                const selects = [makeSelect, priceRangeSelect, registrationYearSelect];
                selects.forEach(select => {
                    if (select.value === '') {
                        select.disabled = true;
                    }
                });
            });

            // Re-enable fields after form submission
            filterForm.addEventListener('submit', function() {
                setTimeout(() => {
                    const selects = [makeSelect, priceRangeSelect, registrationYearSelect];
                    selects.forEach(select => {
                        select.disabled = false;
                    });
                }, 100);
            });
        });
    </script>
    @endpush
   <br> <x-footer />
</body>
</html>
