<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 flex">
            <!-- Sidebar -->
            <div class="bg-gray-700 text-white w-64 h-full py-4 px-3 flex-shrink-0">
                <h2 class="text-2xl font-semibold mb-6">Dashboard</h2>
                <nav class="space-y-2">
                    <a href="{{ route('cars.create') }}" class="block py-2 px-4 rounded hover:bg-gray-800">Post a Car</a>
                    <a href="{{ route('cars.deactivated') }}" class="block py-2 px-4 rounded hover:bg-gray-800">Deactivated Listings</a>
                    <a href="{{ route('test-drives.index') }}" class="block py-2 px-4 rounded hover:bg-gray-800">Test Drive Scheduleing</a>
                    <a href="{{ route('available.cars') }}" class="block py-2 px-4 rounded hover:bg-gray-800">Search Cars</a>
                    <a href="{{ route('bids.index') }}" class="block py-2 px-4 rounded hover:bg-gray-800">Bids</a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="flex-1 ml-4">
                <!-- My Listed Cars Section -->
                <div class="bg-gray-500 overflow-hidden shadow-sm sm:rounded-lg p-6 mb-6">
                    <h3 class="text-lg font-semibold mb-4 text-white">My Listed Cars</h3>
                    
                    @if(session('success'))
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                            {{ session('success') }}
                        </div>
                    @endif

                    <div class="grid grid-cols-1 gap-4">
                        @foreach(auth()->user()->cars as $car)
                            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                                <div class="flex">
                                    <!-- Car Image -->
                                    <div class="w-1/4 h-48">
                                        @if($car->photos->count() > 0)
                                            <img src="{{ Storage::url($car->photos->first()->path) }}" 
                                                 alt="{{ $car->title }}" 
                                                 class="w-full h-full object-cover">
                                        @else
                                            <div class="w-full h-full bg-gray-200 flex items-center justify-center">
                                                <span class="text-gray-400">No Image</span>
                                            </div>
                                        @endif
                                    </div>

                                    <!-- Car Details -->
                                    <div class="w-1/2 p-4">
                                        <h4 class="text-xl font-semibold mb-2">{{ $car->title }}</h4>
                                        
                                        <div class="grid grid-cols-2 gap-4">
                                            <div>
                                                <span class="text-gray-600">Make:</span>
                                                <span class="font-medium ml-2">{{ $car->make }}</span>
                                            </div>
                                            
                                            <div>
                                                <span class="text-gray-600">Model:</span>
                                                <span class="font-medium ml-2">{{ $car->model }}</span>
                                            </div>
                                            
                                            <div>
                                                <span class="text-gray-600">Price:</span>
                                                <span class="font-medium ml-2">${{ number_format($car->price, 2) }}</span>
                                            </div>
                                            
                                            <div>
                                                <span class="text-gray-600">Status:</span>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    {{ $car->status === 'active' ? 'bg-green-100 text-green-800' : 
                                                       ($car->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800') }}">
                                                    {{ ucfirst($car->status) }}
                                                </span>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Actions -->
                                    <div class="w-1/4 p-4 flex flex-col justify-center items-end space-y-2">
                                        @if($car->status === 'active')
                                            <a href="{{ route('cars.edit', $car->id) }}" 
                                               class="bg-indigo-500 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded w-full text-center">
                                                Edit
                                            </a>
                                        @else
                                            <span class="bg-gray-300 text-gray-500 font-bold py-2 px-4 rounded w-full text-center cursor-not-allowed">
                                                Edit
                                            </span>
                                        @endif
                                        
                                        <form action="{{ route('cars.toggle-status', ['car' => $car->id]) }}" method="POST" class="w-full">
                                            @csrf
                                            @method('PUT')
                                            <button type="submit" 
                                                    class="{{ $car->status === 'active' 
                                                        ? 'bg-yellow-500 hover:bg-yellow-700' 
                                                        : 'bg-green-500 hover:bg-green-700' }} 
                                                        text-white font-bold py-2 px-4 rounded w-full">
                                                {{ $car->status === 'active' ? 'Deactivate' : 'Reactivate' }}
                                            </button>
                                        </form>

                                        <!-- Delete Button -->
                                        <form action="{{ route('cars.destroy', $car->id) }}" method="POST" class="w-full" 
                                              onsubmit="return confirm('Are you sure you want to delete this car listing? This action cannot be undone.');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" 
                                                    class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded w-full">
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>

                    @if(auth()->user()->cars->isEmpty())
                        <div class="text-center py-8">
                            <p class="text-gray-500">You haven't listed any cars yet.</p>
                            <a href="{{ route('cars.create') }}" 
                               class="mt-4 inline-flex items-center px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">
                                Post Your First Car
                            </a>
                        </div>
                    @endif
                </div>

                <!-- Available Cars Section -->
                <div class="bg-gray-500 overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <h3 class="text-lg font-semibold mb-4 text-white">Available Cars</h3>
                    
                    <div class="grid grid-cols-1 gap-4">
                        @foreach($availableCars->filter(function($car) { return $car->user_id !== auth()->id(); }) as $car)
                            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                                <div class="flex">
                                    <!-- Car Image -->
                                    <div class="w-1/4 h-48">
                                        @if($car->photos->count() > 0)
                                            <img src="{{ Storage::url($car->photos->first()->path) }}" 
                                                 alt="{{ $car->title }}" 
                                                 class="w-full h-full object-cover">
                                        @else
                                            <div class="w-full h-full bg-gray-200 flex items-center justify-center">
                                                <span class="text-gray-400">No Image</span>
                                            </div>
                                        @endif
                                    </div>

                                    <!-- Car Details -->
                                    <div class="w-1/2 p-4">
                                        <h4 class="text-xl font-semibold mb-2">{{ $car->title }}</h4>
                                        
                                        <div class="grid grid-cols-2 gap-4">
                                            <div>
                                                <span class="text-gray-600">Make:</span>
                                                <span class="font-medium ml-2">{{ $car->make }}</span>
                                            </div>
                                            
                                            <div>
                                                <span class="text-gray-600">Model:</span>
                                                <span class="font-medium ml-2">{{ $car->model }}</span>
                                            </div>
                                            
                                            <div>
                                                <span class="text-gray-600">Price:</span>
                                                <span class="font-medium ml-2">${{ number_format($car->price, 2) }}</span>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Actions -->
                                    <div class="w-1/4 p-4 flex flex-col justify-center items-end space-y-2">
                                        <a href="{{ route('bids.create', $car->id) }}" 
                                           class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded w-full text-center">
                                            Submit Bid
                                        </a>
                                        
                                        <a href="{{ route('test-drives.create', $car->id) }}" 
                                           class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded w-full text-center">
                                            Schedule Test Drive
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>

                    @if($availableCars->filter(function($car) { return $car->user_id !== auth()->id(); })->isEmpty())
                        <div class="text-center py-8">
                            <p class="text-gray-300">No cars are currently available.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const makeSelect = document.getElementById('make');
            const modelSelect = document.getElementById('model');
            
            // Store all models data
            const modelsByMake = @json($modelsByMake);

            // Function to update models dropdown
            function updateModels(selectedMake, selectedModel = '') {
                modelSelect.innerHTML = '<option value="">Select Model</option>';

                if (selectedMake && modelsByMake[selectedMake]) {
                    modelsByMake[selectedMake].forEach(model => {
                        const option = document.createElement('option');
                        option.value = model;
                        option.textContent = model;
                        option.selected = model === selectedModel;
                        modelSelect.appendChild(option);
                    });
                }
            }

            // Handle make selection change
            makeSelect.addEventListener('change', function() {
                updateModels(this.value);
            });

            // Set initial models if make is selected
            if (makeSelect.value) {
                const urlParams = new URLSearchParams(window.location.search);
                const selectedModel = urlParams.get('model');
                updateModels(makeSelect.value, selectedModel);
            }
        });
    </script>
    @endpush
</x-app-layout> 