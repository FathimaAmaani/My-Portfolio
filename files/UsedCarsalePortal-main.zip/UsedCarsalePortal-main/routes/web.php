<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\CarController;
use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\BidController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\TestDriveController;
use App\Http\Controllers\AdminController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\ListingController;
use App\Http\Controllers\DashboardController;


// Public Routes (No Authentication Required)
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/about', function () { return view('about'); })->name('about');
Route::get('/contact', function () { return view('contact'); })->name('contact');
Route::post('/contact-submit', [ContactController::class, 'submit'])->name('contact.submit');
Route::get('/cars/{car}', [CarController::class, 'show'])->name('cars.show');

// Authentication Routes
Route::post('login', [LoginController::class, 'store'])->name('login');
require __DIR__ . '/auth.php';

// Dashboard Route (Authentication Required)
Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');
});

// Admin Routes (Authentication + Admin Required)
Route::middleware('auth')->prefix('admin')->group(function () {
    Route::get('/dashboard', [AdminController::class, 'index'])->name('admin.dashboard');
    
    // Car Management
    Route::get('/cars', [AdminController::class, 'cars'])->name('admin.cars');
    Route::get('/cars/active', [AdminController::class, 'activeCars'])->name('cars.active');
    Route::get('/cars/pending', [AdminController::class, 'pendingCars'])->name('cars.pending');
    Route::get('/cars/deactivated', [AdminController::class, 'deactivatedCars'])->name('cars.deactivated');
    Route::get('/cars/{car}/details', [AdminController::class, 'getCarDetails'])->name('admin.cars.details');
    Route::put('/cars/{car}/toggle-status', [AdminController::class, 'toggleCarStatus'])->name('cars.toggle-status');
    Route::post('/cars/{car}/approve', [AdminController::class, 'approveCar'])->name('cars.approve');
    Route::delete('/cars/{car}', [AdminController::class, 'deleteCar'])->name('cars.delete');
    
    // User Management
    Route::get('/users', [AdminController::class, 'manageUsers'])->name('admin.users');
    Route::post('/assign-role/{userId}', [AdminController::class, 'assignRole'])->name('admin.assign.role');
    Route::delete('/users/{id}', [AdminController::class, 'deleteUser'])->name('admin.users.delete');
    Route::patch('/users/{id}/status', [AdminController::class, 'updateUserStatus'])->name('admin.users.status');
    
    // Appointment & Bid Management
    Route::get('/appointments', [AdminController::class, 'manageAppointments'])->name('admin.appointments');
    Route::get('/bids', [AdminController::class, 'manageBids'])->name('admin.bids');
    
    // Listing Management
    Route::post('/deactivate-listings', [ListingController::class, 'deactivate'])->name('deactivate-listings');
});

// Authenticated User Routes
Route::middleware(['auth'])->group(function () {
    // Profile Routes
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::delete('/profile/picture', [ProfileController::class, 'deleteProfilePicture'])->name('profile.picture.delete');
    
    // Car Routes
    Route::get('/cars.create', [CarController::class, 'create'])->name('cars.create');
    Route::post('/cars', [CarController::class, 'store'])->name('cars.store');
    Route::get('/cars/{car}/edit', [CarController::class, 'edit'])->name('cars.edit');
    Route::put('/cars/{car}/toggle-status', [CarController::class, 'toggleStatus'])->name('cars.toggle-status');
    Route::put('/cars/{car}', [CarController::class, 'update'])->name('cars.update');
    Route::delete('/cars/{car}', [CarController::class, 'destroy'])->name('cars.destroy');
    Route::get('/my-cars', [CarController::class, 'dashboard'])->name('cars.dashboard');
    Route::get('/deactivated-listings', [CarController::class, 'deactivatedListings'])->name('cars.deactivated');
    Route::get('/available-cars', [CarController::class, 'availableCars'])->name('available.cars');
    
    // Bid Routes
    Route::get('/bids', [BidController::class, 'index'])->name('bids.index');
    Route::get('/cars/{car}/bid', [BidController::class, 'create'])->name('bids.create');
    Route::post('/cars/{car}/bid', [BidController::class, 'store'])->name('bids.store');
    Route::get('/bids/{bid}/edit', [BidController::class, 'edit'])->name('bids.edit');
    Route::put('/bids/{bid}', [BidController::class, 'update'])->name('bids.update');
    Route::patch('/bids/{bid}/status', [BidController::class, 'updateStatus'])->name('bids.update.status');
   

    // Test Drive Routes
    Route::get('/test-drives', [TestDriveController::class, 'index'])->name('test-drives.index');
    Route::get('/test-drives/create/{car}', [TestDriveController::class, 'create'])->name('test-drives.create');
    Route::post('/test-drives', [TestDriveController::class, 'store'])->name('test-drives.store');
    Route::get('/test-drives/{testDrive}/edit', [TestDriveController::class, 'edit'])->name('test-drives.edit');
    Route::put('/test-drives/{testDrive}', [TestDriveController::class, 'update'])->name('test-drives.update');
    Route::patch('/test-drives/{testDrive}/status', [TestDriveController::class, 'updateStatus'])->name('test-drives.update.status');
});

Route::middleware('auth')->prefix('admin')->group(function () {
    Route::post('/bids/{bid}/status', [AdminController::class, 'updateBidStatus'])->name('admin.bids.update.status');
    Route::get('/test-drives', [AdminController::class, 'manageTestDrives'])->name('admin.test-drives');
    Route::patch('/admin/cars/test-drives/{testDrive}', [AdminController::class, 'updateTestDrive'])->name('admin.cars.test-drives.update');
});

// Car management routes
Route::prefix('admin/cars')->name('admin.cars.')->group(function () {
    Route::get('/active', [AdminController::class, 'activeCars'])->name('active');
    Route::get('/deactivated', [AdminController::class, 'deactivatedCars'])->name('deactivated');
    Route::put('/{car}/toggle-status', [AdminController::class, 'toggleCarStatus'])->name('toggle-status');
    Route::delete('/{car}/delete', [AdminController::class, 'deleteCar'])->name('delete');
});
