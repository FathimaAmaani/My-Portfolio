<?php

namespace App\Http\Controllers;

use App\Models\Bid;
use App\Models\Car;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BidController extends Controller
{
    public function index()
    {
        $userBids = Bid::where('user_id', Auth::id())
            ->with(['car', 'car.user'])
            ->orderBy('created_at', 'desc')
            ->get();


        $receivedBids = Bid::whereHas('car', function ($query) {
            $query->where('user_id', Auth::id());
        })->with(['user', 'car'])
            ->orderBy('created_at', 'desc')
            ->get();


        return view('bids.index', compact('userBids', 'receivedBids'));
    }

    public function create(Car $car)
    {
        return view('bids.create', compact('car'));
    }

    public function store(Request $request, Car $car)
    {
        $validated = $request->validate([
            'amount' => 'required|numeric|min:1',
            'message' => 'nullable|string|max:500'
        ]);

        $bid = Bid::create([
            'car_id' => $car->id,
            'user_id' => Auth::id(),
            'amount' => $validated['amount'],
            'message' => $validated['message'] ?? null,
            'status' => 'pending'
        ]);

        return redirect()->route('bids.index')
            ->with('success', 'Bid submitted successfully.');
    }

    public function edit(Bid $bid)
    {
        if ($bid->user_id !== Auth::id() || $bid->status !== 'pending') {
            return redirect()->back()->with('error', 'You cannot edit this bid.');
        }

        return view('bids.edit', compact('bid'));
    }

    public function update(Request $request, Bid $bid)
    {
        if ($bid->user_id !== Auth::id() || $bid->status !== 'pending') {
            return redirect()->back()->with('error', 'You cannot edit this bid.');
        }

        $validated = $request->validate([
            'amount' => 'required|numeric|min:1',
            'message' => 'nullable|string|max:500'
        ]);

        $bid->update($validated);

        return redirect()->route('bids.index')
            ->with('success', 'Bid updated successfully.');
    }

    
    public function updateStatus(Request $request, Bid $bid)
{
    if ($bid->car->user_id !== Auth::id()) {
        return redirect()->back()->with('error', 'Unauthorized action.');
    }

    $request->validate([
        'status' => 'required|in:accepted,rejected',
    ]);

    // Update the bid status
    $bid->update(['status' => $request->status]);

    return redirect()->route('bids.index')->with('success', 'Bid status updated successfully!');
}

} 