<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Car;
use App\Models\Make;
use App\Models\CarModel;
use Illuminate\Support\Facades\Auth;
class HomeController extends Controller
{
    public function index(Request $request)
    {
        $query = Car::where('status', 'active');

        // Make filter
        if ($request->filled('make')) {
            $query->where('make', $request->make);
        }

        // Price range filter
        if ($request->filled('price_range')) {
            $range = explode('-', $request->price_range);
            if (count($range) == 2) {
                $query->whereBetween('price', [$range[0], $range[1]]);
            } elseif ($request->price_range == '50000+') {
                $query->where('price', '>=', 50000);
            }
        }

        // Registration year filter
        if ($request->filled('registration_year')) {
            $query->where('registration_year', $request->registration_year);
        }

        // Get unique makes for the filter
        $makes = Car::distinct()->pluck('make')->sort();
        
        // Get unique years for the filter (last 30 years)
        $currentYear = date('Y');
        $years = range($currentYear, $currentYear - 30);

        $cars = $query->with('photos')->paginate(9);

        return view('home', compact('cars', 'makes', 'years'));
    }

    public function dashboard()
    {
        $user = Auth::user();
        $myCars = Car::where('user_id', $user->id)
                     ->where('status', 'active')
                     ->get();

        return view('dashboard', compact('myCars'));
    }

    public function store(Request $request)
    {
        // ... existing validation and car creation code ...

        // After successfully creating the car
        return redirect()->route('dashboard')
            ->with('success', 'Car posted successfully!');
    }
}
