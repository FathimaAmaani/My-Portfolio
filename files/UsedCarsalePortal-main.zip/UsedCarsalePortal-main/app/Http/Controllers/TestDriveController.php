<?php

namespace App\Http\Controllers;

use App\Models\Car;
use App\Models\TestDrive;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;


class TestDriveController extends Controller
{
    public function index()
    {
        $userTestDrives = TestDrive::where('user_id', Auth::id())
            ->with(['car', 'car.user'])
            ->orderBy('scheduled_at')
            ->get();

        $receivedTestDrives = TestDrive::whereHas('car', function ($query) {
            $query->where('user_id', Auth::id());
        })->with(['user', 'car'])
            ->orderBy('scheduled_at')
            ->get();


        return view('test-drives.index', compact('userTestDrives', 'receivedTestDrives'));
    }

    public function create(Request $request)
    {
        $car = Car::findOrFail($request->car);
        
        // Get all booked time slots for this car
        $bookedSlots = TestDrive::where('car_id', $car->id)
            ->where('status', '!=', 'rejected')
            ->where('scheduled_at', '>=', now())
            ->pluck('scheduled_at')
            ->map(function($datetime) {
                return Carbon::parse($datetime)->format('Y-m-d H:i');
            })
            ->toArray();

        // Generate available time slots
        $availableSlots = $this->generateAvailableTimeSlots($bookedSlots);

        return view('test-drives.create', compact('car', 'availableSlots'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'car_id' => 'required|exists:cars,id',
            'scheduled_at' => 'required|date|after:now',
            'notes' => 'nullable|string|max:500',
        ]);

        // Check if the time slot is still available
        $isSlotTaken = TestDrive::where('car_id', $request->car_id)
            ->where('status', '!=', 'rejected')
            ->where('scheduled_at', Carbon::parse($request->scheduled_at))
            ->exists();

        if ($isSlotTaken) {
            return back()->with('error', 'This time slot has already been booked. Please choose another time.');
        }

        TestDrive::create([
            'user_id' => Auth::id(),
            'car_id' => $request->car_id,
            'scheduled_at' => $request->scheduled_at,
            'notes' => $request->notes,
            'status' => 'pending'
        ]);

        return redirect()->route('test-drives.index')
            ->with('success', 'Test drive request submitted successfully.');
    }

    public function update(Request $request, TestDrive $testDrive)
    {
        // Check if the user owns this test drive request and it's still pending
        if ($testDrive->user_id !== Auth::id() || $testDrive->status !== 'pending') {
            return redirect()->back()->with('error', 'You cannot edit this test drive request.');
        }

        $request->validate([
            'scheduled_at' => 'required|date|after:now',
            'notes' => 'nullable|string|max:500',
        ]);

        // Check if the new time slot is available
        $isSlotTaken = TestDrive::where('car_id', $testDrive->car_id)
            ->where('id', '!=', $testDrive->id)
            ->where('status', '!=', 'rejected')
            ->where('scheduled_at', Carbon::parse($request->scheduled_at))
            ->exists();

        if ($isSlotTaken) {
            return back()->with('error', 'This time slot has already been booked. Please choose another time.');
        }

        $testDrive->update([
            'scheduled_at' => $request->scheduled_at,
            'notes' => $request->notes
        ]);

        return redirect()->route('test-drives.index')
            ->with('success', 'Test drive request updated successfully.');
    }

    public function edit(TestDrive $testDrive)
    {
        // Check if the user owns this test drive request and it's still pending
        if ($testDrive->user_id !== Auth::id() || $testDrive->status !== 'pending') {
            return redirect()->back()->with('error', 'You cannot edit this test drive request.');
        }

        // Get all booked time slots for this car
        $bookedSlots = TestDrive::where('car_id', $testDrive->car_id)
            ->where('id', '!=', $testDrive->id)
            ->where('status', '!=', 'rejected')
            ->where('scheduled_at', '>=', now())
            ->pluck('scheduled_at')
            ->map(function($datetime) {
                return Carbon::parse($datetime)->format('Y-m-d H:i');
            })
            ->toArray();

        // Generate available time slots
        $availableSlots = $this->generateAvailableTimeSlots($bookedSlots);

        return view('test-drives.edit', compact('testDrive', 'availableSlots'));
    }


    public function updateStatus(Request $request, TestDrive $testDrive)
{
    // Verify that the user owns the car associated with this test drive
    if ($testDrive->car->user_id !== Auth::id()) {
        return redirect()->back()->with('error', 'Unauthorized action.');
    }
    $request->validate([
        'status' => 'required|in:approved,rejected',
    ]);

    // Update the test drive status
    $testDrive->update(['status' => $request->status]);

    return redirect()->route('test-drives.index')->with('success', 'Test drive status updated successfully!');
}


    private function generateAvailableTimeSlots($bookedSlots)
    {
        $slots = [];
        $startDate = Carbon::tomorrow();
        $endDate = Carbon::tomorrow()->addDays(14);

        while ($startDate <= $endDate) {
            if ($startDate->isWeekday()) { // Monday to Friday only
                for ($hour = 9; $hour <= 17; $hour++) { // 9 AM to 5 PM
                    $slotTime = $startDate->copy()->setHour($hour)->setMinute(0);
                    $slotTimeString = $slotTime->format('Y-m-d H:i');

                    if (!in_array($slotTimeString, $bookedSlots)) {
                        $slots[] = [
                            'value' => $slotTimeString,
                            'label' => $slotTime->format('l, F j, Y g:i A')
                        ];
                    }
                }
            }
            $startDate->addDay();
        }

        return $slots;
    }
} 