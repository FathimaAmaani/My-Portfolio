<?php

namespace App\Http\Controllers;

use App\Models\Car;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function dashboard()
    {
        // Check if user is admin
        if (Auth::user()->is_admin) {
            return redirect()->route('admin.dashboard');
        }

        // For non-admin users, fetch the required data
        $cars = Car::where('user_id', Auth::id())
                   ->where('status', 'active')
                   ->with('photos')
                   ->latest()
                   ->paginate(10);
                   
        // Fetch available cars
        $availableCars = Car::where('status', 'active')
                           ->with('photos')
                           ->get();
        
        // Create an associative array of makes and their models
        $modelsByMake = Car::where('status', 'active')
            ->select('make', 'model')
            ->distinct()
            ->get()
            ->groupBy('make')
            ->map(function ($cars) {
                return $cars->pluck('model')->sort()->values();
            });

        return view('dashboard', compact('cars', 'availableCars', 'modelsByMake'));
    }
}
