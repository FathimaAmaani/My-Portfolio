<?php

namespace App\Http\Controllers;

use App\Models\Car;
use App\Models\CarPhoto;
use App\Models\CarModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;


class CarController extends Controller
{
    public function index()
    {
        // Load cars with their photos and user relationships
        $cars = Car::with(['photos', 'user'])
            ->where('status', 'active')
            ->latest()
            ->get();
        
        return view('cars.index', compact('cars'));
    }

    public function create()
    {
        return view('cars.create'); 
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'make' => 'required|string|max:255',
            'model' => 'required|string|max:255',
            'registration_year' => 'required|integer',
            'price' => 'required|numeric',
            'description' => 'required|string',
            'mileage' => 'required|integer',
            'body_type' => 'required|string',
            'transmission' => 'required|string',
            'engine_size' => 'required|string',
            'fuel_type' => 'required|string',
            'color' => 'required|string',
            'condition' => 'required|string',
            'photos.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        $car = Car::create([
            ...$validated,
            'user_id' => Auth::id(),
            'status' => 'active',
        ]);

        if ($request->hasFile('photos')) {
            foreach ($request->file('photos') as $photo) {
                $path = $photo->store('car-photos', 'public');
                CarPhoto::create([
                    'car_id' => $car->id,
                    'path' => $path
                ]);
            }
        }

        return redirect()->route('dashboard')->with('success', 'Car posted successfully!');
    }

    public function show(Car $car)
    {
        $car->load(['user', 'photos']);
        return view('cars.show', compact('car'));
    }
    
    public function edit($id)
    {
        $car = Car::with('photos')->findOrFail($id);
        return view('cars.edit', compact('car'));
    }

    public function update(Request $request, Car $car)
    {
        // Check ownership
        if (Auth::id() !== $car->user_id) {
            abort(403);
        }

        // Validate the request
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'make' => 'required|string|max:255',
            'model' => 'required|string|max:255',
            'condition' => 'required|in:new,used',
            'registration_year' => 'required|integer',
            'mileage' => 'required|numeric',
            'price' => 'required|numeric',
            'description' => 'required|string',
            'photos.*' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'remove_photos.*' => 'nullable|exists:car_photos,id'
        ]);

        // Update the car with validated data
        $car->update($validated);

        // Handle photo removal if any
        if ($request->has('remove_photos')) {
            foreach ($request->remove_photos as $photoId) {
                $photo = CarPhoto::find($photoId);
                if ($photo && $photo->car_id === $car->id) {
                    Storage::disk('public')->delete($photo->path);
                    $photo->delete();
                }
            }
        }

        // Handle new photo uploads if any
        if ($request->hasFile('photos')) {
            foreach ($request->file('photos') as $photo) {
                $path = $photo->store('car-photos', 'public');
                $car->photos()->create(['path' => $path]);
            }
        }

        return redirect()->route('dashboard')->with('success', 'Car updated successfully!');
    }

    public function deactivate(Car $car)
    {
        if (Auth::id() !== $car->user_id) {
            abort(403);
        }

        $car->update(['status' => 'inactive']);
        return back()->with('success', 'Car listing has been deactivated');
    }

    public function toggleStatus(Car $car)
    {
        if (Auth::id() !== $car->user_id) {
            abort(403);
        }

        $car->status = $car->status === 'active' ? 'inactive' : 'active';
        $car->save();

        $message = $car->status === 'active' ? 'Car reactivated successfully!' : 'Car deactivated successfully!';
        return back()->with('success', $message);
    }

    public function deactivatedListings()
    {
        $cars = Car::where('user_id', Auth::id())
                   ->where('status', 'inactive')
                   ->latest()
                   ->paginate(10);
                   
        return view('cars.deactivated', compact('cars'));
    }

    public function dashboard()
    {
        $cars = Car::where('user_id', Auth::id())
                   ->where('status', 'active')
                   ->with('photos')
                   ->latest()
                   ->paginate(10);
                   
        return view('dashboard', compact('cars'));
    }

    public function availableCars(Request $request)
    {
        $query = Car::where('status', 'active');

        // Make filter
        if ($request->filled('make')) {
            $query->where('make', $request->make);
        }

        // Price range filter
        if ($request->filled('price_range')) {
            $range = explode('-', $request->price_range);
            if (count($range) == 2) {
                $query->whereBetween('price', [$range[0], $range[1]]);
            } elseif ($request->price_range == '50000+') {
                $query->where('price', '>=', 50000);
            }
        }

        // Registration year filter
        if ($request->filled('registration_year')) {
            $query->where('registration_year', $request->registration_year);
        }

        // Get unique makes for the filter
        $makes = Car::distinct()->pluck('make')->sort();
        
        // Get unique years for the filter (last 30 years)
        $currentYear = date('Y');
        $years = range($currentYear, $currentYear - 30);

        $cars = $query->with('photos')->paginate(9);

        return view('cars.available', compact('cars', 'makes', 'years'));
    }

    public function destroy(Car $car)
    {
        try {
            DB::beginTransaction();

            // Check if user is authorized to delete this car
            if ($car->user_id !== Auth::id()) {
                return back()->with('error', 'Unauthorized action.');
            }

            // Delete related photos from storage
            foreach ($car->photos as $photo) {
                if (Storage::disk('public')->exists($photo->path)) {
                    Storage::disk('public')->delete($photo->path);
                }
                $photo->delete();
            }

            // Delete related records
            if ($car->bids()->exists()) {
                $car->bids()->delete();
            }

            if ($car->testDrives()->exists()) {
                $car->testDrives()->delete();
            }

            // Finally delete the car
            $car->delete();

            DB::commit();

            return redirect()->route('dashboard')->with('success', 'Car listing deleted successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            \Illuminate\Support\Facades\Log::error('Car deletion error: ' . $e->getMessage());
            return back()->with('error', 'Failed to delete car listing. Please try again.');
        }
    }

}
