<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Car;
use App\Models\Appointment;
use App\Models\Bid;
use App\Models\TestDrive;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

class AdminController extends Controller
{
    /**
     * Display admin dashboard
     */
    public function index()
    {
        $users = User::all();
        $cars = Car::all();
        $activeCars = Car::where('status', 'active')->count();
        $deactiveCars = Car::where('status', 'deactivated')->count(); // This returns an integer
        $Bids = Bid::all();
        $TestDrives = TestDrive::all();
        
        $recentBids = Bid::with(['user', 'car'])->latest()->take(5)->get();
        $recentTestDrives = TestDrive::with(['user', 'car'])->latest()->take(5)->get();

        return view('admin.dashboard', compact(
            'users', 
            'activeCars', // This is an integer
            'deactiveCars',
            'Bids',
            'TestDrives',
            'recentBids',
            'recentTestDrives'
        ));
    }

    /**
     * Manage Cars
     */
    public function cars()
    {
        // Fetch active and deactivated cars
        $activeCars = Car::where('status', 'active')->get(); // Fetch active cars
        $deactivatedCars = Car::where('status', 'deactivated')->get(); // Fetch deactivated cars

        return view('admin.cars.cars', compact('activeCars', 'deactivatedCars'));
    }

    /**
     * Approve a car listing
     */
    public function approveCar($id)
    {
        $car = Car::findOrFail($id);
        $car->status = 'active';
        $car->save();

        return redirect()->back()->with('success', 'Car approved successfully!');
    }

    /**
     * Deactivate a car listing
     */
    public function deactivateCar($id)
    {
        $car = Car::findOrFail($id);
        $car->status = 'deactivated';
        $car->save();

        return redirect()->back()->with('success', 'Car deactivated successfully!');
    }

    /**
     * Manage Users
     */
    public function manageUsers()
    {
        $users = User::all();
        return view('admin.users', compact('users'));
    }

    /**
     * Assign role to user
     */
    public function assignRole(Request $request, $userId)
    {
        $user = User::findOrFail($userId);
        // Prevent modifying own role
        if ($user->getAttribute('id') === Auth::id()) {
            return redirect()->back()->with('error', 'You cannot modify your own role!');
        }

        // Toggle admin status based on submitted role
        $user->is_admin = ($request->role === 'admin');
        $user->save();

        $message = $user->is_admin 
            ? 'User has been granted admin access successfully!' 
            : 'Admin access has been removed successfully!';

        return redirect()->back()->with('success', $message);
    }

    /**
     * Manage Appointments
     */
    public function manageAppointments()
    {
        $appointments = Appointment::with(['user', 'car'])->get();
        return view('admin.appointments', compact('appointments'));
    }

    /**
     * Manage Bids
     */
    public function manageBids()
    {
        $bids = Bid::with(['user', 'car'])->latest()->get();
        return view('admin.bids', compact('bids'));
    }

    /**
     * Delete User
     */
    public function deleteUser($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->back()->with('success', 'User deleted successfully!');
    }

    /**
     * Update User Status
     */
    public function updateUserStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:active,inactive'
        ]);

        $user = User::findOrFail($id);
        $user->status = $request->status;
        $user->save();

        return redirect()->back()->with('success', 'User status updated successfully!');
    }

    public function updateBidStatus(Request $request, $bidId)
    {
        $bid = Bid::findOrFail($bidId);
        $bid->status = $request->status;
        $bid->save();

        return redirect()->back()->with('success', 'Bid status updated successfully!');
    }

    public function getCarDetails(Car $car)
    {
        // Load the car with its photos
        $car->load('photos');
        return response()->json($car);
    }

    public function toggleCarStatus($id)
    {
        $car = Car::findOrFail($id);
        $car->status = $car->status === 'active' ? 'deactivated' : 'active';
        $car->save();

        return redirect()->back()->with('success', 'Car status updated successfully!');
    }

    public function deleteCar(Car $car)
    {
        try {
            // Delete associated photos first
            if ($car->photos) {
                foreach ($car->photos as $photo) {
                    Storage::delete($photo->path);
                    $photo->delete();
                }
            }
            
            // Delete the car
            $car->delete();
            
            return redirect()->back()->with('success', 'Car has been permanently deleted.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Failed to delete car. Please try again.');
        }
    }

    public function manageTestDrives()
    {
        $testDrives = TestDrive::with(['user', 'car'])
            ->orderBy('created_at', 'desc')
            ->get();

        return view('admin.test-drives', [
            'testDrives' => $testDrives
        ]);
    }

    public function updateTestDrive(TestDrive $testDrive, Request $request)
    {
        $testDrive->update([
            'status' => $request->status
        ]);

        return redirect()->back()->with('success', 'Test drive status updated successfully.');
    }

    public function dashboard()
    {
        try {
            // Get counts directly using count()
            $activeCarsCount = Car::where('status', 'active')->count();
            $deactivatedCarsCount = Car::where('status', 'deactivated')->count();

            $users = User::all();
            $pendingBids = Bid::where('status', 'pending')->count();
            $pendingTestDrives = TestDrive::where('status', 'pending')->count();
            $recentBids = Bid::with(['user', 'car'])->latest()->take(5)->get();
            $recentTestDrives = TestDrive::with(['user', 'car'])->latest()->take(5)->get();

            return view('admin.dashboard', [
                'users' => $users,
                'activeCars' => $activeCarsCount,
                'deactivatedCarsCount' => $deactivatedCarsCount,
                'pendingBids' => $pendingBids,
                'pendingTestDrives' => $pendingTestDrives,
                'recentBids' => $recentBids,
                'recentTestDrives' => $recentTestDrives
            ]);
        } catch (\Exception $e) {
            // Log the error and return with a message
            Log::error('Dashboard Error: ' . $e->getMessage());
            return back()->with('error', 'An error occurred while loading the dashboard.');
        }
    }

    public function activeCars()
    {
        $cars = Car::active()->get();
        return view('admin.cars.active', compact('cars'));
    }

    public function deactivatedCars()
    {
        $cars = Car::deactivated()->get();
        return view('admin.cars.deactivated', compact('cars'));
    }
}