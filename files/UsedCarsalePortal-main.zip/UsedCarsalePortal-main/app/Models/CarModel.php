<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CarModel extends Model
{
    use HasFactory;

    protected $fillable = ['make_id', 'name'];
    public function make()
    {
        return $this->belongsTo(Make::class); // Ensure this is correctly set up
    }


    public function cars()
    {
        return $this->hasMany(Car::class, 'car_model_id'); // Ensure the foreign key is correctly defined
    }
}
