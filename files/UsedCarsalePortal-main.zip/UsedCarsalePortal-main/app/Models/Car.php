<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Http\Controllers\TestDriveController;
use Illuminate\Support\Facades\Storage;

class Car extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'make',
        'model',
        'registration_year',
        'price',
        'description',
        'mileage',
        'body_type',
        'transmission',
        'fuel_type',
        'engine_size',
        'number_of_owners',
        'service_history',
        'color',
        'features',
        'condition',
        'user_id',
        'status'
    ];

    protected $casts = [
        'features' => 'array',
        'service_history' => 'boolean',
        'price' => 'decimal:2'
    ];

    protected $appends = ['image'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function carModel()
    {
        return $this->belongsTo(CarModel::class);
    }

    public function photos()
    {
        return $this->hasMany(CarPhoto::class);
    }

    public function testDrives()
    {
        return $this->hasMany(TestDriveController::class);
    }

    public function bids()
    {
        return $this->hasMany(Bid::class);
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeDeactivated($query)
    {
        return $query->where('status', 'deactivated');
    }

    public function getImageAttribute()
    {
        if ($this->photos->isNotEmpty()) {
            return Storage::url($this->photos->first()->path);
        }
        return null;
    }
}
