<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Car;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Create 'makes' table
        Schema::create('makes', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->timestamps();
        });

        // Create 'car_models' table
        Schema::create('car_models', function (Blueprint $table) {
            $table->id();
            $table->foreignId('make_id')
                ->constrained('makes')
                ->onDelete('cascade'); // Foreign key to 'makes'
            $table->string('name');
            $table->timestamps();
        });

        // Create 'cars' table
        Schema::create('cars', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('make');
            $table->string('model');
            $table->integer('registration_year');
            $table->decimal('price', 12, 2);
            $table->text('description');
            $table->string('status')->default('active');
            
            // New fields
            $table->integer('mileage')->nullable();
            $table->enum('body_type', ['Saloon', 'Hatchback', 'Convertible', 'Coupe', 'SUV', 'MPV', 'Estate', '4X4', 'Other']);
            $table->enum('transmission', ['Automatic', 'Manual', 'Tiptronic', 'Other']);
            $table->enum('fuel_type', ['Petrol', 'Diesel', 'Electric', 'Hybrid', 'Gas', 'Other']);
            $table->string('engine_size');
            $table->integer('number_of_owners')->default(1);
            $table->boolean('service_history')->default(false);
            $table->string('color');
            $table->json('features')->nullable(); // For optional extras
            $table->string('condition');
            
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->timestamps();
        });

        // Create 'car_photos' table for multiple photos
        Schema::create('car_photos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('car_id')->constrained('cars')->onDelete('cascade');
            $table->string('path'); // Changed from photo_path to path to match our model
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Drop tables in reverse order to respect foreign key constraints
        Schema::dropIfExists('car_photos');
        Schema::dropIfExists('cars');
        Schema::dropIfExists('car_models');
        Schema::dropIfExists('makes');
    }
};
