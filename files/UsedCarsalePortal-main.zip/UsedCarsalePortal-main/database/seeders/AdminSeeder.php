<?php

// Filepath: database/seeders/AdminSeeder.php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'name' => 'Admin',
            'email' => 'admin@example.com',
            'email_verified_at' => now(),
            'gender' => 'Male',
            'address' => '123 Admin Street',
            'phone_number' => '1234567890',
            'profile_picture' => null,
            'password' => Hash::make('password1234'), // You should choose a strong password
            'is_admin' => true, // Ensure you have an 'is_admin' field in the users table
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
