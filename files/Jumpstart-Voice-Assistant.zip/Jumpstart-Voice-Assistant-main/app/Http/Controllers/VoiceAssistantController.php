<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class VoiceAssistantController extends Controller
{
    public function index()
    {
        return view('voice-assistant'); // 👈 blade file in /resources/views/voice-assistant.blade.php
    }
    public function generateReply(Request $request)
    {
        $input = $request->input('text');

        // Create a more structured prompt that won't be included in the response
        $prompt = <<<EOT
<|system|>
You are a helpful retail assistant. Provide clear, concise answers about retail, shopping, and customer service.
<|user|>
{$input}
<|assistant|>
EOT;

        $response = Http::withHeaders([
            'Authorization' => 'Bearer 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',
        ])->post('https://api-inference.huggingface.co/models/mistralai/Mixtral-8x7B-Instruct-v0.1', [
            'inputs' => $prompt,
            'parameters' => [
                'max_new_tokens' => 250,
                'temperature' => 0.7,
                'top_p' => 0.95,
                'return_full_text' => false
            ]
        ]);

        $generated = $response->json();
        
        // Get just the assistant's response
        $reply = $generated[0]['generated_text'] ?? 'Sorry, I could not understand.';
        
        // Clean up the response
        $reply = trim($reply);

        return response()->json([
            'reply' => $reply
        ]);
    }
}
