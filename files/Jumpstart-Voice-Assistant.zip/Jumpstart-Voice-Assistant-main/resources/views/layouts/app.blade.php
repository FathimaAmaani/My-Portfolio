<!DOCTYPE html>
<html>
<head>
    <title>JumpStart Retail Shop - @yield('title')</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen">
    <nav class="bg-white shadow-lg">
        <div class="max-w-6xl mx-auto px-4">
            <div class="flex justify-between items-center py-4">
                <div class="text-xl font-bold text-blue-600">
                    <a href="/">JumpStart Retail Shop</a>
                </div>
                <div class="space-x-4">
                    @guest
                        <a href="{{ route('login') }}" class="text-gray-600 hover:text-blue-600">Login</a>
                        <a href="{{ route('register') }}" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Register</a>
                    @else
                        <a href="/voice-assistant" class="text-gray-600 hover:text-blue-600">Voice Assistant</a>
                        <form method="POST" action="{{ route('logout') }}" class="inline">
                            @csrf
                            <button type="submit" class="text-gray-600 hover:text-blue-600">Logout</button>
                        </form>
                    @endguest
                </div>
            </div>
        </div>
    </nav>

    <main class="py-12">
        <div class="max-w-6xl mx-auto px-4">
            @yield('content')
        </div>
    </main>
</body>
</html> 