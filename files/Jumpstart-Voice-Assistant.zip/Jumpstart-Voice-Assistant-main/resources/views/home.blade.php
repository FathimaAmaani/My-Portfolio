@extends('layouts.app')

@section('title', 'Home - Jumpstart Retail Shop')

@section('content')
<div class="text-center mb-12">
    <h1 class="text-4xl font-bold text-gray-800 mb-4">Welcome to Jumpstart Retail Shop</h1>
    <p class="text-xl text-gray-600">Your AI-powered retail assistant</p>
</div>

<div class="grid md:grid-cols-3 gap-8">
    <div class="bg-white p-6 rounded-xl shadow-lg">
        <div class="text-blue-600 text-4xl mb-4">
            <i class="fas fa-microphone"></i>
        </div>
        <h3 class="text-xl font-semibold mb-2">Voice Commands</h3>
        <p class="text-gray-600">Interact with our AI assistant using natural voice commands</p>
    </div>

    <div class="bg-white p-6 rounded-xl shadow-lg">
        <div class="text-blue-600 text-4xl mb-4">
            <i class="fas fa-shopping-cart"></i>
        </div>
        <h3 class="text-xl font-semibold mb-2">Retail Support</h3>
        <p class="text-gray-600">Get instant answers to your retail-related questions</p>
    </div>

    <div class="bg-white p-6 rounded-xl shadow-lg">
        <div class="text-blue-600 text-4xl mb-4">
            <i class="fas fa-robot"></i>
        </div>
        <h3 class="text-xl font-semibold mb-2">Smart AI</h3>
        <p class="text-gray-600">Powered by advanced AI for intelligent responses</p>
    </div>
</div>

<div class="text-center mt-12">
    <a href="/voice-assistant" class="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700 inline-block">
        Try Voice Assistant
    </a>
</div>
@endsection 