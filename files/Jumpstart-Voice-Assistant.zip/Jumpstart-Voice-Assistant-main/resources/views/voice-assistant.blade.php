<!DOCTYPE html>
<html>
<head>
    <title>Jumpstart Retail Shop - Voice Assistant</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
    <div class="bg-white p-6 rounded-xl shadow-lg w-full max-w-2xl">
        <h2 class="text-2xl font-bold text-center text-blue-600 mb-4">🎙️ JumpStart Retail Shop Assistant</h2>

        <div id="chat" class="bg-gray-50 p-4 rounded-lg h-96 overflow-y-auto mb-4 border border-gray-300">
            <p class="text-sm text-gray-500 text-center">Your conversation will appear here...</p>
        </div>

        <div class="mb-4">
            <textarea id="transcript" class="w-full p-3 border border-gray-300 rounded-lg" rows="3" placeholder="Your speech will appear here..." readonly></textarea>
        </div>

        <div class="flex justify-center space-x-4">
            <button id="startBtn" onclick="startListening()" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition duration-300 flex items-center">
                <i class="fas fa-microphone mr-2"></i> Start Listening
            </button>
            <button id="stopBtn" onclick="stopListening()" class="bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-6 rounded-lg transition duration-300 flex items-center hidden">
                <i class="fas fa-stop mr-2"></i> Stop
            </button>
        </div>
    </div>

    <script>
        let recognition;
        const startBtn = document.getElementById('startBtn');
        const stopBtn = document.getElementById('stopBtn');
        const transcript = document.getElementById('transcript');
        const chat = document.getElementById('chat');

        function startListening() {
            recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
            recognition.continuous = true;
            recognition.interimResults = true;

            recognition.onstart = () => {
                startBtn.classList.add('hidden');
                stopBtn.classList.remove('hidden');
                transcript.value = '';
            };

            recognition.onresult = (event) => {
                let finalTranscript = '';
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    if (event.results[i].isFinal) {
                        finalTranscript += event.results[i][0].transcript;
                    }
                }
                if (finalTranscript) {
                    transcript.value = finalTranscript;
                    sendToAI(finalTranscript);
                }
            };

            recognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                stopListening();
            };

            recognition.start();
        }

        function stopListening() {
            if (recognition) {
                recognition.stop();
                startBtn.classList.remove('hidden');
                stopBtn.classList.add('hidden');
            }
        }

        function sendToAI(text) {
            chat.innerHTML += `
                <div class="mb-2 text-right">
                    <div class="inline-block bg-blue-100 text-blue-800 px-4 py-2 rounded-lg shadow">
                        You: ${text}
                    </div>
                </div>
            `;

            fetch('/api/generate-reply', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                },
                body: JSON.stringify({ text: text })
            })
            .then(res => res.json())
            .then(data => {
                chat.innerHTML += `
                    <div class="mb-2 text-left">
                        <div class="inline-block bg-green-100 text-green-800 px-4 py-2 rounded-lg shadow">
                            Assistant: ${data.reply}
                        </div>
                    </div>
                `;
                chat.scrollTop = chat.scrollHeight;
            })
            .catch(error => {
                console.error('Error:', error);
                chat.innerHTML += `
                    <div class="mb-2 text-left">
                        <div class="inline-block bg-red-100 text-red-800 px-4 py-2 rounded-lg shadow">
                            Error: Could not get response from AI
                        </div>
                    </div>
                `;
            });
        }
    </script>
</body>
</html>
