<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VoiceAssistantController;

Route::get('/', function () {
    return view('home');
});

Route::get('/voice-assistant', [VoiceAssistantController::class, 'index'])->middleware('auth');
Route::post('/api/generate-reply', [VoiceAssistantController::class, 'generateReply'])->middleware('auth');

// Authentication Routes
require __DIR__.'/auth.php';

