# ExerciseFitness_Tracker
A fitness tracker web application and BMI calculator using PHP
