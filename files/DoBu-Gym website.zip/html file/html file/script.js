function alertHomePge() {
  alert("you are trying to go back to the homepage");
}
function dateTime() {
  document.getElementById("date").innerHTML = Date();
}
function gallery1(img) {
  img.style.width = "450px";
}
function gallery2(img) {
  img.style.width = "350px";
}
function loadImage() {
  alert("images are loaded");
}
